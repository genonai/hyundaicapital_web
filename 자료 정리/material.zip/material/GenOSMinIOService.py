"""GenOS 클러스터 MinIO 업로드 → Presigned URL (내부망 cdn-api).

  POST http://llmops-cdn-api-service:8080/minio/upload/temp       multipart(file, hostname) → temp 버킷, 임시 URL
  POST http://llmops-cdn-api-service:8080/minio/presigned/create  json(hostname, bucket_name, object_name) → 기존 객체 URL

인증 없음(클러스터 내부 전용). 응답 봉투: {"code": 0, "data": {"presigned_url": "..."}}
받은 URL 을 답변 마크다운(`![제목](url)`)에 넣으면 채팅 화면에서 이미지·차트가 렌더된다.
"""
import os
import mimetypes
import requests


class GenOSMinIOService:
    def __init__(self, hostname: str | None = None,
                 cdn_url: str = "http://llmops-cdn-api-service:8080"):
        """
        :param hostname: 사용자가 접속하는 GenOS 도메인. presigned URL 의 호스트로 쓰인다.
                         예: "https://genos.genon.ai". 생략 시 파드 환경변수에서 읽는다.
        """
        self.cdn_url = cdn_url.rstrip("/")
        self.hostname = hostname or os.getenv("G__CLUSTER_HOSTNAME") or os.getenv("_CLUSTER_HOSTNAME", "")
        if not self.hostname:
            print("⚠ hostname 이 비었다. presigned URL 호스트가 잘못 나올 수 있다.")

    def upload_and_get_presigned_url(self, file_path: str, timeout: float = 60.0) -> str:
        """로컬 파일을 temp 버킷에 올리고 임시 공개 URL 을 돌려준다(파일명은 UUID 로 바뀜, 만료 있음)."""
        if not os.path.exists(file_path):
            raise FileNotFoundError(file_path)
        mime = mimetypes.guess_type(file_path)[0] or "application/octet-stream"
        with open(file_path, "rb") as f:
            res = requests.post(f"{self.cdn_url}/minio/upload/temp",
                                files={"file": (os.path.basename(file_path), f, mime)},
                                data={"hostname": self.hostname}, timeout=timeout).json()
        if res.get("code") != 0:
            raise RuntimeError(f"업로드 실패: {res}")
        return res["data"]["presigned_url"]

    # 이전 이름 호환
    upload_html_and_get_presigned_url = upload_and_get_presigned_url

    def get_doc_resource_url(self, doc_id: int, file_path: str,
                             bucket_name: str = "user-media", timeout: float = 30.0) -> str | None:
        """이미 MinIO 에 있는 객체(예: 문서 리소스)의 presigned URL. object_name = f"{doc_id}/{file_path}"."""
        res = requests.post(f"{self.cdn_url}/minio/presigned/create", json={
            "hostname": self.hostname, "bucket_name": bucket_name, "object_name": f"{doc_id}/{file_path}",
        }, timeout=timeout).json()
        return (res.get("data") or {}).get("presigned_url")
