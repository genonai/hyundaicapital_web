"""[Flowise 워크플로우 Python Step 전용]
이 스크립트는 워크플로우 컨테이너(main_socketio.sio_server) 안에서 실행된다.
  - 화면까지 전달되는 emit 이벤트: token / sourceDocuments / agentReasoning / agentFlowExecutedData / error
  - result 는 답변 텍스트 누적용이다. token 을 이미 흘렸으면 폐기되므로 출처는 sourceDocuments 로 따로 emit 한다.
  - HITL(action)은 이 경로에서 전달되지 않는다. 필요하면 코드서빙으로 만든다 → GenOSCodeServing_main.py
  - 코드서빙(FastAPI)에서는 이 방식이 아니라 SSE `data: {"event": "token", ...}` 프레임을 쓴다.
"""
async def run(data):
    import asyncio
    import inspect
    import json
    try:
        from main_socketio import sio_server
    except ImportError:
        sio_server = None
    sid = data.get('socketIOClientId')


    async def emit_event(event_name, payload):
        if sio_server and sid:
            await sio_server.emit(event_name, payload, room=sid)
        return {"event": event_name, "data": payload}

    async def return_cot(iterable):
        yield await emit_event('token', "<think>\n")

        if inspect.isasyncgen(iterable):
            async for token in iterable:
                await asyncio.sleep(0.5)
                yield await emit_event('token', token)
        else:
            for token in iterable:
                await asyncio.sleep(0.5)
                yield await emit_event('token', token)

        yield await emit_event('token', "\n</think>\n")

    async def return_reasoning(rationale_text):
        reasoning_payload = [
            {
                "nodeId": "python_step_1",
                "nodeLabel": "Visible Reasoner (Python)",
                "data": {
                    "output": {
                        "content": json.dumps({
                            "visible_rationale": rationale_text
                        }, ensure_ascii=False)
                    }
                }
            }
        ]
        yield await emit_event('agentFlowExecutedData', reasoning_payload)
        await asyncio.sleep(1)

    async def return_answer(iterable):
        answer = ""
        if inspect.isasyncgen(iterable):
            async for token in iterable:
                answer += token
                await asyncio.sleep(0.5)
                yield await emit_event('token', token)
        else:
            for token in iterable:
                answer += token
                await asyncio.sleep(0.5)
                yield await emit_event('token', token)

        yield {"event": "result", "data": {"text": answer}}

    reasoning_tokens = "이것은 파이썬에서 실시간으로 생각하는 Reasoning 과정입니다."
    cot_tokens = ["이것은 ", "파이썬에서 ", "실시간으로 ", "생각하는 ", "cot", "과정입니다..."]
    answer_tokens = ['안','녕','하','세','요\n','반','갑','습','니','다.']

    async for chunk in return_reasoning(reasoning_tokens):
        yield  chunk

    async for chunk in return_cot(cot_tokens):
        yield chunk

    async for chunk in return_answer(answer_tokens):
        yield chunk


