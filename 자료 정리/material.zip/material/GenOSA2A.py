"""GenOS A2A(Agent-to-Agent) 에이전트 호출: JSON-RPC 2.0.

  Agent Card : GET  {genos_url}/a2a/agents/{agent_card_id}/.well-known/agent.json
  호출       : POST {genos_url}/a2a/{agent_card_id}
  인증       : Authorization: Bearer {인증키}  (A2A 에이전트 상세 > 인증 키)

A2A 는 다른 리소스와 달리 경로에 /api/gateway 접두어가 붙지 않는다.
인그레스가 /a2a/ 를 rewrite 없이 게이트웨이로 넘긴다.

허용 method (레거시 사양): tasks/send · message/send  /  스트리밍: tasks/sendSubscribe · message/stream
"""
import json
import requests


def _headers(bearer_token: str) -> dict:
    return {"Authorization": f"Bearer {bearer_token}", "Content-Type": "application/json"}


def _jsonrpc_body(question: str, method: str, timeout: int = 600, context_id: str = "") -> dict:
    return {
        "jsonrpc": "2.0",
        "id": "genos-edu",
        "method": method,
        "params": {
            "message": {"role": "user", "parts": [{"type": "text", "text": question}]},
            "contextId": context_id,            # 멀티턴이면 이전 응답의 contextId 를 넣는다
            "timeout": timeout,
        },
    }


def get_agent_card(agent_card_id: int, bearer_token: str, genos_url: str) -> dict | None:
    """에이전트 명함(이름·설명·스킬·지원 확장) 조회."""
    url = f"{genos_url.rstrip('/')}/a2a/agents/{agent_card_id}/.well-known/agent.json"
    res = requests.get(url, headers=_headers(bearer_token), timeout=30)
    res.raise_for_status()
    return res.json()


def call_agent(agent_card_id: int, bearer_token: str, question: str, genos_url: str,
               timeout: int = 600, method: str = "message/send", context_id: str = "") -> dict:
    """에이전트를 호출하고 최종 응답을 한 번에 받는다.
    답변은 result.status.message.parts 또는 result.artifacts[*].parts 에 있다."""
    url = f"{genos_url.rstrip('/')}/a2a/{agent_card_id}"
    res = requests.post(url, headers=_headers(bearer_token),
                        json=_jsonrpc_body(question, method, timeout, context_id), timeout=timeout + 20)
    res.raise_for_status()
    out = res.json()
    if "error" in out:
        raise RuntimeError(f"A2A error: {out['error']}")
    return out


def extract_text(response: dict) -> str:
    """call_agent 응답에서 텍스트만 뽑는다 (status.message.parts → artifacts 순)."""
    result = response.get("result") or {}
    parts = ((result.get("status") or {}).get("message") or {}).get("parts") or []
    if not parts:
        for art in result.get("artifacts") or []:
            parts += art.get("parts") or []
    return "".join(p.get("text", "") for p in parts if isinstance(p, dict))


def call_agent_stream(agent_card_id: int, bearer_token: str, question: str, genos_url: str,
                      timeout: int = 600, method: str = "message/stream", context_id: str = ""):
    """SSE 이벤트를 도착하는 대로 yield 한다: {"event": 이벤트명 or None, "data": payload}"""
    url = f"{genos_url.rstrip('/')}/a2a/{agent_card_id}"
    with requests.post(url, headers=_headers(bearer_token),
                       json=_jsonrpc_body(question, method, timeout, context_id),
                       stream=True, timeout=timeout + 20) as res:
        res.raise_for_status()
        event_name = None
        for line in res.iter_lines(decode_unicode=True):
            line = (line or "").strip()
            if not line:
                continue
            if line.startswith("event:"):
                event_name = line[6:].strip()
            elif line.startswith("data:"):
                raw = line[5:].strip()
                try:
                    data = json.loads(raw)
                except json.JSONDecodeError:
                    data = raw
                if event_name is None and isinstance(data, dict):        # GenOS 는 event: 줄 없이 data: 만 보낸다
                    event_name = (data.get("result") or {}).get("kind")   # status-update / artifact-update
                yield {"event": event_name, "data": data}
                event_name = None
