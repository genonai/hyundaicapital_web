"""[Flowise 워크플로우 Python Step 전용]
이 스크립트는 워크플로우 컨테이너(main_socketio.sio_server) 안에서 실행된다.
  - 화면까지 전달되는 emit 이벤트: token / sourceDocuments / agentReasoning / agentFlowExecutedData / error
  - result 는 답변 텍스트 누적용이다. token 을 이미 흘렸으면 폐기되므로 출처는 sourceDocuments 로 따로 emit 한다.
  - HITL(action)은 이 경로에서 전달되지 않는다. 필요하면 코드서빙으로 만든다 → GenOSCodeServing_main.py
  - 코드서빙(FastAPI)에서는 이 방식이 아니라 SSE `data: {"event": "token", ...}` 프레임을 쓴다.
"""
async def run(data: dict) -> dict:
    import os
    import json
    from pydantic import BaseModel, ConfigDict
    import requests
    import httpx
    from util.genos_utils import genos_import
    import asyncio
    import inspect
    import json
    from pydantic import BaseModel

    # <답변모델 정의>
    # ========================================================================
    class RoutingAnswer(BaseModel):
        route : str
        reason : str
    # ========================================================================


    # <히스토리 관리>
    # =================여기서 선언되는 변수는 전부 전역변수============================
    # 히스토리 구조는 [system_prompt, Q1, A1, Q2, A2, Q3, A3 .. , user_input]

    redis = genos_import('redis')
    sid = data.get('socketIOClientId')
    r = redis.Redis(host='llmops-redis-service', port=6379, db=0)
    session_id = data.get("chatId", "")
    question = data.get("question", "")
    history = []


    def save_history(hist_list):
        if session_id:
            r.set(session_id, json.dumps(hist_list))

    def get_message_template(system_prompt:str, user_input:str, history:list):
        messages = [{"role": "system", "content": system_prompt}]
        messages.extend(history)
        messages.append({"role": "user", "content": user_input})
        body = {
        "messages": messages,
        "stream": True
            }
        return body

    try:
        from main_socketio import sio_server
    except ImportError:
        sio_server = None
    # 기존 히스토리 로드
    if session_id:
        raw_history = r.get(session_id)
        if raw_history:
            history = json.loads(raw_history)
            print('[History] session_id가 존재하여 히스토리를 불러왔습니다.')
            print(f'[History] 불러온 히스토리 개수: {len(history)}')

    # ========================================================================



    # <출력 관리>
    # ========================================================================

    async def emit_event(event_name, payload):
        if sio_server and sid:
            await sio_server.emit(event_name, payload, room=sid)
        return {"event": event_name, "data": payload}

    async def return_cot(iterable):
        yield await emit_event('token', "<think>\n")

        if inspect.isasyncgen(iterable):
            async for token in iterable:
                yield await emit_event('token', token)
        else:
            for token in iterable:
                yield await emit_event('token', token)

        yield await emit_event('token', "\n</think>\n")

    async def return_reasoning(rationale_text):
        reasoning_payload = [
            {
                "nodeId": "python_step_1",
                "nodeLabel": "Visible Reasoner (Python)",
                "data": {
                    "output": {
                        "content": json.dumps({
                            "visible_rationale": rationale_text
                        }, ensure_ascii=False)
                    }
                }
            }
        ]
        yield await emit_event('agentFlowExecutedData', reasoning_payload)

    async def return_answer(iterable, sourceDocuments = None):
        answer = ""
        if inspect.isasyncgen(iterable):
            async for token in iterable:
                answer += token
                yield await emit_event('token', token)
        else:
            for token in iterable:
                answer += token
                yield await emit_event('token', token)

        result_data = {"text": answer}
        if sourceDocuments:
            result_data["sourceDocuments"] = sourceDocuments

        yield await emit_event('result', result_data)
        history.append({"role" : "user", "content" : question})
        history.append({"role": "assistant", "content": answer})
        save_history(history)
        print(f"[History] 질문 저장 : {question}")
        answer_preview = answer[:min(len(answer), 30)].replace('\n', ' ')
        print(f"[History] 답변 저장 : {answer_preview}...")

    # ========================================================================



    # <MCP, LLM 클래스 선언>
    # ========================================================================

    class GenOSMCPServer:
        def __init__(self, mcp_server_id: str, bearer_token: str, genos_url: str):
            self.mcp_server_id = mcp_server_id
            self.url = f"{genos_url}/api/gateway/mcp/{mcp_server_id}/mcp"
            self.headers = {
                "Authorization": f"Bearer {bearer_token}",
                "Accept": "application/json, text/event-stream",
                "Content-Type": "application/json"
            }
            print(f"MCP Server ID {mcp_server_id}이(가) 설정되었습니다.")

        def _build_payload(self, tool_name: str, arguments: dict):
            """MCP(JSON-RPC) 규격에 맞는 페이로드를 자동으로 생성합니다."""
            return {
                "jsonrpc": "2.0",
                "id": 1,
                "method": "tools/call",
                "params": {
                    "name": tool_name,
                    "arguments": arguments
                }
            }

        def call(self, tool_name: str, arguments: dict):
            body = self._build_payload(tool_name, arguments)
            try:
                # SSE 데이터를 받기 위해 stream=True 옵션 사용
                res = requests.post(self.url, json=body, headers=self.headers, stream=True)

                # 이전 대화에서 다룬 Event-Stream 파싱 로직
                for line in res.iter_lines():
                    if line:
                        decoded_line = line.decode('utf-8')
                        # 'data: ' 로 시작하는 알맹이 JSON만 추출
                        if decoded_line.startswith('data: '):
                            json_str = decoded_line.replace('data: ', '', 1)
                            return json.loads(json_str)

                # 스트리밍이 아닌 일반 JSON으로 응답이 왔을 경우 대비
                return res.json()

            except Exception as e:
                print(f'MCP 도구 호출 중 오류 발생: {e}')
                return None

        async def async_call(self, tool_name: str, arguments: dict):
            body = self._build_payload(tool_name, arguments)
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    # 비동기 환경에서의 스트리밍 요청 처리
                    async with client.stream("POST", self.url, json=body, headers=self.headers) as response:
                        async for line in response.aiter_lines():
                            if line.startswith('data: '):
                                json_str = line.replace('data: ', '', 1)
                                return json.loads(json_str)

                    # 예외적으로 스트리밍이 아닐 경우
                    return await response.aread().json()

            except Exception as e:
                print(f'MCP 도구 비동기 호출 중 오류 발생: {e}')
                return None


    class GenOSLLMServing:
        def __init__(self, serving_id: int, bearer_token: str, genos_url: str):
            self.serving_id = serving_id
            self.url = f"{genos_url}/api/gateway/rep/serving/{serving_id}"
            self.headers = dict(Authorization=f"Bearer {bearer_token}")
            self.endpoint = f"{self.url}/v1/models"
            if serving_id and bearer_token:
                print(f'model: {serving_id}번과 토큰이 입력되었습니다.')
            else:
                print('serving id 혹은 인증키가 입력되지 않았습니다.')

        def make_openai_json_schema(self, model: type[BaseModel]) -> dict:
            if not model.model_config:
                model.model_config = ConfigDict(extra = 'forbid')
            return {
                "type": "json_schema",
                "json_schema": {
                    "name": model.__name__,       # 클래스 이름 자동 반영
                    "strict": True,
                    "schema": model.model_json_schema()
                }
            }

        def call(self, system_prompt :str = '당신은 유용한 어시스턴트입니다.', question :str = '안녕?', output_format: BaseModel = None):
            """
            LLM output의 text만 내보냅니다.
            """
            body = {
                'messages' : [
                    {'role' : 'system', 'content' : system_prompt},
                    {'role' : 'user', 'content' : question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            try:
                response = requests.post(endpoint, headers=self.headers, json=body, stream=True)
                result = response.json()['choices'][0]['message']['content']
            except KeyError as e:
                print(response.json())
                print(f'llm 서빙 호출 중 keyerror 발생: {e}')
                return None
            except requests.exceptions.RequestException as e:
                print(f'llm 서빙 호출 중 오류 발생 : {e}')
                return None

            if output_format:
                return json.loads(result)
            else:
                return result

        async def async_call(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?', output_format: BaseModel = None):
            body = {
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"

            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    response = await client.post(endpoint, headers=self.headers, json=body)
                result = response.json()['choices'][0]['message']['content']
            except KeyError as e:
                print(response.json())
                print(f'llm 서빙 호출 중 keyerror 발생: {e}')
                return None
            except httpx.RequestError as e:
                print(f'llm 서빙 호출 중 오류 발생 : {e}')
                return None

            if output_format:
                return json.loads(result)
            else:
                return result

        def call_all(self, system_prompt :str = '당신은 유용한 어시스턴트입니다.', question :str = '안녕?', output_format :BaseModel = None):
            """
            LLM output의 모든 데이터를 내보냅니다.
            """
            body = {
                'messages' : [
                    {'role' : 'system', 'content' : system_prompt},
                    {'role' : 'user', 'content' : question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            return result

        def call_with_body(self, body: dict, output_format=None):
            """
            LLM output 데이터를 요청합니다. body에 'stream': True가 있으면 제너레이터를 반환합니다.
            """
            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            is_stream = body.get("stream", False)

            # stream 인자를 넘겨줍니다.
            response = requests.post(endpoint, headers=self.headers, json=body, stream=is_stream)
            response.raise_for_status()  # HTTP 에러 발생 시 예외 처리

            if is_stream:
                # 스트리밍 처리 로직 (제너레이터 함수)
                def generate():
                    for line in response.iter_lines():
                        if line:
                            decoded_line = line.decode('utf-8')
                            # SSE 표준 포맷은 "data: {json_string}"
                            if decoded_line.startswith('data: '):
                                data_str = decoded_line[6:]  # 'data: ' 부분 제거

                                # 스트림 종료 신호
                                if data_str.strip() == '[DONE]':
                                    break

                                try:
                                    chunk = json.loads(data_str)
                                    # OpenAI 규격에서 스트리 밍은 'message' 대신 'delta'를 사용합니다.
                                    if chunk.get("choices"):
                                        delta = chunk['choices'][0].get('delta', {})
                                        if 'content' in delta and delta['content']:
                                            yield delta['content']
                                except json.JSONDecodeError:
                                    pass  # 파싱할 수 없는 청크는 무시

                # 제너레이터 객체 반환
                return generate()
            else:
                # 스트리밍이 아닐 경우 기존처럼 전체 JSON 반환
                return response.json()

        async def async_call_with_body(self, body: dict, output_format=None):
            """
            LLM output 데이터를 비동기로 요청합니다. body에 'stream': True가 있으면 비동기 제너레이터를 반환합니다.
            """
            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            is_stream = body.get("stream", False)

            if is_stream:
                # 비동기 스트리밍 처리 로직 (비동기 제너레이터 함수)
                async def generate():
                    async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                        async with client.stream("POST", endpoint, headers=self.headers, json=body) as response:
                            response.raise_for_status()
                            async for line in response.aiter_lines():
                                if line:
                                    if line.startswith('data: '):
                                        data_str = line[6:]  # 'data: ' 부분 제거

                                        # 스트림 종료 신호
                                        if data_str.strip() == '[DONE]':
                                            break

                                        try:
                                            chunk = json.loads(data_str)
                                            # 안전하게 choices가 있는지 확인
                                            if chunk.get('choices'):
                                                delta = chunk['choices'][0].get('delta', {})
                                                if 'content' in delta and delta['content']:
                                                    yield delta['content']
                                        except json.JSONDecodeError:
                                            pass  # 파싱할 수 없는 청크는 무시

                # 비동기 제너레이터 객체 반환
                return generate()

            else:
                # 스트리밍이 아닐 경우 기존처럼 단일 요청 후 전체 JSON 반환
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    response = await client.post(endpoint, headers=self.headers, json=body)
                    response.raise_for_status()
                    return response.json()

    # ========================================================================



    # <환경변수 로드>
    # ========================================================================

    SERVING_ID = os.getenv("LLM_SERVING_ID", "")
    BEARER_TOKEN = os.getenv("LLM_BEARER_TOKEN", "")
    GENOS_URL = os.getenv("GENOS_URL", "")
    MCP_SERVER_ID = os.getenv("MCP_SERVER_ID")
    MCP_SERVER_BEARER_TOKEN = os.getenv("MCP_SERVER_BEARER_TOKEN")

    # ========================================================================

    # <MCP Server, LLM 선언>
    # ========================================================================

    mcp_server = GenOSMCPServer(mcp_server_id=MCP_SERVER_ID, bearer_token=MCP_SERVER_BEARER_TOKEN, genos_url=GENOS_URL)
    llm = GenOSLLMServing(serving_id=SERVING_ID, bearer_token=BEARER_TOKEN, genos_url=GENOS_URL)

    # ========================================================================



    # <RAG 로직>
    # ========================================================================
    async def rag(question):

        tool_name = "retriever"
        args = {
            "query" : question,
            "topk" : 4
        }
        resp = mcp_server.call(tool_name=tool_name, arguments=args)
        sourceDocuments = json.loads(resp['result']['content'][0]['text'])   # [{pageContent, metadata}]: metadata 에 file_name·i_page·doc_id·security_level 포함되게 retriever 쪽에서 구성

        system_prompt = "사용자의 질문에 대해 검색된 문서를 바탕으로 친절히 답변하세요. 답변 마지막에는 반드시 참조한 문서의 파일명과 페이지를 적시하세요."
        user_input = f"사용자 질문 : {question}\n 검색된 문서 : {sourceDocuments}\n"
        body = get_message_template(system_prompt, user_input, history)

        generator = await llm.async_call_with_body(body=body)
        answer_generator = return_answer(generator, sourceDocuments=sourceDocuments)
        return answer_generator

    # ========================================================================



    # <CHAT 로직>
    # ========================================================================

    async def chat(question):
        system_prompt = f"""사용자의 질문에 대해 친절히 답변하세요."""
        user_input = f"사용자 질문 : {question}"
        body = get_message_template(system_prompt, user_input, history)

        generator = await llm.async_call_with_body(body = body)
        answer_generator = return_answer(generator)
        return answer_generator

    # ========================================================================

    # <ROUTING 로직>
    # ========================================================================

    async def routing(question):
        routing_system_prompt = """사용자의 질문을 판단하여 RAG로 분기할지 CHAT으로 분기할지 결정하세요. 
        도로교통법에 대한 질의를 던진 경우 RAG로, 그 외의 질문은 CHAT으로 분기하세요.
        답변은 json 형식으로 'route' 라는 key에 'RAG 혹은 'CHAT' 둘 중 하나만 입력하세요. 
        그리고 "reason" key에 route 결과에 대한 이유를 100자 이내로 작성하세요."""
        routing_user_input = f"사용자 질문 : {question}"
        route_result = llm.call(system_prompt=routing_system_prompt, question=routing_user_input,
                                output_format=RoutingAnswer)

        return route_result

    # ========================================================================



    # <RAG / CHAT 분기>
    # ========================================================================
    route_result = await routing(question)

    route_decision = route_result.get('route', 'CHAT') if isinstance(route_result, dict) else 'CHAT'
    route_reason = route_result.get("reason", "")
    print("[Routing] 라우팅 결과:", route_decision)

    if route_reason:
        route_reason += f"\n\n 최종 결정 : {route_decision}"
        async for chunk in return_reasoning(route_reason):
            yield chunk

    if route_decision == 'RAG':
        generator = await rag(question = question)
        async for chunk in generator:
            yield chunk

    else:
        generator = await chat(question = question)
        async for chunk in generator:
            yield chunk

    # ========================================================================