"""GenOS 벡터DB(Weaviate) 검색 클라이언트.

주의할 점 세 가지.
  - Weaviate 는 익명 접근이 꺼져 있어 VDB 전용 Read Key 가 반드시 필요하다.
    「벡터DB 상세 > 인증 키」에서 발급하며, 그 VDB 컬렉션에만 권한이 있다(루트 키 아님).
  - 앱 채팅은 사용자 보안등급으로 security_level <= 등급 필터를 자동으로 걸지만,
    직접 검색하면 필터를 직접 넣어야 한다(user_level 인자).
  - 질의 임베딩은 VDB 적재에 쓴 것과 같은 임베딩 서빙으로 해야 한다.

주소는 클러스터 내부 llmops-weaviate-service HTTP 8080 / gRPC 50051 이다.
"""
import weaviate
from weaviate.classes.init import Auth
from weaviate.classes.query import Filter, MetadataQuery

try:                                   # 패키지로 import 하면 상대 import, 스크립트 폴더에서 쓰면 절대 import
    from .GenOSEmbedding import GenOSEmbedding
except ImportError:
    from GenOSEmbedding import GenOSEmbedding


class GenOSVectorDB:
    def __init__(self,
                 vdb_key: str,                      # VDB 전용 Read Key (벡터DB 상세 > 인증 키)
                 idx: str,                          # VDB 인덱스 = Weaviate 컬렉션명 (예: "K6960b01d…")
                 embedding_serving_id: int,
                 embedding_bearer_token: str,
                 genos_url: str,
                 weaviate_host: str = "llmops-weaviate-service",
                 http_port: int = 8080,
                 grpc_port: int = 50051):
        self.client = weaviate.connect_to_custom(
            http_host=weaviate_host, http_port=http_port, http_secure=False,
            grpc_host=weaviate_host, grpc_port=grpc_port, grpc_secure=False,
            auth_credentials=Auth.api_key(vdb_key),
            skip_init_checks=True,
        )
        if not self.client.collections.exists(idx):
            raise ValueError(f"컬렉션 {idx} 이 없거나 이 키의 권한 범위가 아니다.")
        self.collection = self.client.collections.get(idx)
        self.emb = GenOSEmbedding(serving_id=embedding_serving_id,
                                  bearer_token=embedding_bearer_token, genos_url=genos_url)
        print(f"VDB {idx} 연결 (임베딩 서빙 {embedding_serving_id})")

    # ------------------------------------------------------------ 내부
    def _vector(self, query: str) -> list[float]:
        return self.emb.call(query)[0]["embedding"]

    @staticmethod
    def _filters(user_level: int | None, file_name_pattern: str | None, folder_path: str | None):
        """보안등급 / 파일명 부분일치 / AI드라이브 폴더 필터를 AND 로 묶는다. 전부 None 이면 None."""
        f = None
        if user_level is not None:
            f = Filter.by_property("security_level").less_or_equal(user_level)
        if file_name_pattern:      # file_name 은 word 토크나이즈: 토큰 안 부분일치. 예: "*근로*"
            g = Filter.by_property("file_name").like(file_name_pattern)
            f = g if f is None else (f & g)
        if folder_path:            # 드라이브 루트→폴더 노드 ID 체인. 예: "/2002/3499/"
            g = Filter.by_property("ai_drive_node_path").like(f"{folder_path}*")
            f = g if f is None else (f & g)
        return f

    @staticmethod
    def _rows(res) -> list[dict]:
        out = []
        for o in res.objects:
            row = dict(o.properties)
            if o.metadata is not None:
                row["_score"] = o.metadata.score if o.metadata.score is not None else o.metadata.distance
            out.append(row)
        return out

    # ------------------------------------------------------------ 검색
    def dense_search(self, query: str, topk: int = 4, user_level: int | None = None) -> list[dict]:
        """벡터 유사도 검색."""
        res = self.collection.query.near_vector(
            near_vector=self._vector(query), limit=topk,
            filters=self._filters(user_level, None, None),
            return_metadata=MetadataQuery(distance=True))
        return self._rows(res)

    def bm25_search(self, query: str, topk: int = 4, user_level: int | None = None) -> list[dict]:
        """키워드(BM25) 검색. 암호화 적재 VDB 는 text 가 암호문이라 결과가 비어 나온다."""
        res = self.collection.query.bm25(
            query=query, query_properties=["text"], limit=topk,
            filters=self._filters(user_level, None, None),
            return_metadata=MetadataQuery(score=True))
        return self._rows(res)

    def hybrid_search(self, query: str, topk: int = 4, alpha: float = 0.5,
                      user_level: int | None = None,
                      file_name_pattern: str | None = None,
                      folder_path: str | None = None) -> list[dict]:
        """벡터+키워드 혼합. alpha 0=키워드만, 1=벡터만."""
        res = self.collection.query.hybrid(
            query=query, vector=self._vector(query), alpha=alpha, limit=topk,
            filters=self._filters(user_level, file_name_pattern, folder_path),
            return_metadata=MetadataQuery(score=True))
        return self._rows(res)

    def search_from_file_name(self, query: str, file_name_pattern: str, topk: int = 4,
                              alpha: float = 0.5, user_level: int | None = None) -> list[dict]:
        """파일명 패턴으로 좁힌 hybrid 검색 (Filter RAG). 호환용: hybrid_search 를 감싼다."""
        return self.hybrid_search(query, topk, alpha, user_level, file_name_pattern)

    def show_documents(self) -> list[str]:
        res = self.collection.query.fetch_objects(limit=10000, return_properties=["file_name"])
        return list(dict.fromkeys(o.properties["file_name"] for o in res.objects))

    # ------------------------------------------------------------ 채팅 규약 변환
    @staticmethod
    def to_source_documents(rows: list[dict]) -> list[dict]:
        """검색 결과 → GenOS 채팅 sourceDocuments 규약.

        text 만 pageContent 로 옮기고 **나머지 프로퍼티는 전부 metadata** 로 넘긴다.
        출처 카드에는 file_name·i_page 만 보이지만, 뷰어 하이라이트(chunk_bboxes)·썸네일(media_files)·
        보안등급 필터(security_level)·휴지통 제외(doc_id)가 metadata 를 읽는다. 화이트리스트로 고르면 빠진다.
        """
        docs = []
        for r in rows:
            meta = {k: v for k, v in r.items() if k not in ("text", "_score") and v is not None}
            docs.append({"pageContent": r.get("text") or "", "metadata": meta})
        return docs

    def close(self):
        self.client.close()
