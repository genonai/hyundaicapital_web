"""코드서빙 **서버** 템플릿: 이 파일을 레포 루트에 main.py 로 두면 그대로 배포된다.

플랫폼 규약(container-services/code-serving/scripts/entrypoint.sh):
  - 레포 루트 main.py 의 모듈 변수 `app` 을 `uvicorn main:app --port 8080` 으로 자동 기동
  - requirements.txt 가 있으면 첫 부팅에 pip install (fastapi·uvicorn·httpx 는 베이스 이미지에 이미 있음)
  - GET /health 는 startupProbe 가 호출: 없으면 배포 실패
  - 설정은 코드에 넣지 말고 리비전 > 환경 설정(env / 시작 커맨드)으로 주입

채팅앱 연동 규약(워크플로우로 사용):
  요청  POST {chat_path}  {"question": str, "stream": bool, "humanInput"?: dict}
  응답  stream=false → JSON {"code": 0, "errMsg": "success", "data": {"text": ..., "sourceDocuments": [...]}}
        stream=true  → SSE  data: {"event": "token"|"sourceDocuments"|"action"|"error"|"end", "data": ...}\n\n
  검증  어드민 「검증」 버튼은 question="__verify__" 를 보낸다 → LLM 부르지 말고 code 0 즉답
"""
import json
import os

import httpx
from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse

GENOS_URL        = os.getenv("GENOS_URL", "https://genos.genon.ai")
LLM_SERVING_ID   = os.getenv("LLM_SERVING_ID", "")
LLM_BEARER_TOKEN = os.getenv("LLM_BEARER_TOKEN", "")
LLM_MODEL        = os.getenv("LLM_MODEL", "")
SYSTEM_PROMPT    = os.getenv("SYSTEM_PROMPT", "당신은 유용한 어시스턴트입니다. 한국어로 답하세요.")

LLM_URL = f"{GENOS_URL.rstrip('/')}/api/gateway/rep/serving/{LLM_SERVING_ID}/v1/chat/completions"
HEADERS = {"Authorization": f"Bearer {LLM_BEARER_TOKEN}"}

app = FastAPI()


def sse(event: str, data) -> str:
    """GenOS 채팅 SSE 프레임. `data: ` 뒤 공백 필수, 한 줄 JSON, 빈 줄로 종료."""
    return "data: " + json.dumps({"event": event, "data": data}, ensure_ascii=False) + "\n\n"


def _payload(question: str, stream: bool) -> dict:
    body = {"messages": [{"role": "system", "content": SYSTEM_PROMPT},
                         {"role": "user", "content": question}],
            "temperature": 0.3, "stream": stream}
    if LLM_MODEL:
        body["model"] = LLM_MODEL
    return body


async def llm_stream(question: str):
    """LLM 서빙(OpenAI 호환 SSE) → delta.content 토큰만 yield."""
    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream("POST", LLM_URL, headers=HEADERS, json=_payload(question, True)) as res:
            res.raise_for_status()
            async for line in res.aiter_lines():
                line = line.strip()
                if not line.startswith("data:"):
                    continue                              # ": keep-alive" 주석 등 무시
                chunk = line[5:].strip()
                if chunk == "[DONE]":
                    break
                delta = (json.loads(chunk).get("choices") or [{}])[0].get("delta", {})
                if delta.get("content"):
                    yield delta["content"]


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/chat")
async def chat(request: Request):
    body = await request.json()
    question = (body.get("question") or "").strip()
    human_input = body.get("humanInput")      # HITL 2턴째. question 은 "" 로 오고 이 값만 온다 → 상태를 직접 보관해야 함

    if question == "__verify__":              # 검증 버튼: LLM 호출 없이 즉답
        return {"code": 0, "errMsg": "success", "data": {"text": "verified"}}

    if not body.get("stream"):                # 어드민 워크플로우 테스트 등 비스트리밍 경로
        if not question:
            return {"code": 1, "errMsg": "question is empty", "data": {"text": ""}}
        try:
            text = "".join([t async for t in llm_stream(question)])
        except Exception as e:                # 실패도 HTTP 200 + code != 0 봉투로: genportal 이 errMsg 를 사용자에게 보여준다
            return {"code": 1, "errMsg": f"[CODE_SERVING_ERROR] {type(e).__name__}: {e}", "data": {"text": ""}}
        return {"code": 0, "errMsg": "success", "data": {"text": text}}

    async def gen():
        try:
            if human_input:                   # 예제: HITL 응답 확인만. 실제로는 interactionId 로 저장한 상태를 이어간다
                yield sse("token", f"선택을 받았습니다: {json.dumps(human_input.get('values'), ensure_ascii=False)}")
            else:
                async for token in llm_stream(question):
                    yield sse("token", token)
        except Exception as e:
            yield sse("error", f"[CODE_SERVING_ERROR] {type(e).__name__}: {e}")
        yield sse("end", None)

    return StreamingResponse(gen(), media_type="text/event-stream", headers={"X-Accel-Buffering": "no"})
