from pydantic import BaseModel, ConfigDict
import json
import requests
import httpx


class GenOSLLMServing:
    def __init__(self, serving_id: int, bearer_token: str, genos_url: str):
        self.serving_id = serving_id
        self.url = f"{genos_url}/api/gateway/rep/serving/{serving_id}"
        self.headers = dict(Authorization=f"Bearer {bearer_token}")
        self.endpoint = f"{self.url}/v1/models"
        if serving_id and bearer_token:
            print(f'model: {serving_id}번과 토큰이 입력되었습니다.')
        else:
            print('serving id 혹은 인증키가 입력되지 않았습니다.')

    def make_openai_json_schema(self, model: type[BaseModel]) -> dict:
        if not model.model_config:
            model.model_config = ConfigDict(extra='forbid')
        return {
            "type": "json_schema",
            "json_schema": {
                "name": model.__name__,  # 클래스 이름 자동 반영
                "strict": True,
                "schema": model.model_json_schema()
            }
        }

    def call(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?', output_format: BaseModel = None):
        """
        LLM output의 text만 내보냅니다.
        """
        body = {
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': question}
            ]
        }

        if output_format:
            body['response_format'] = self.make_openai_json_schema(output_format)

        endpoint = f"{self.url}/v1/chat/completions"
        try:
            response = requests.post(endpoint, headers=self.headers, json=body, stream=True)
            result = response.json()['choices'][0]['message']['content']
        except KeyError as e:
            print(response.json())
            print(f'llm 서빙 호출 중 keyerror 발생: {e}')
            return None
        except requests.exceptions.RequestException as e:
            print(f'llm 서빙 호출 중 오류 발생 : {e}')
            return None

        if output_format:
            return json.loads(result)
        else:
            return result

    async def async_call(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?',
                         output_format: BaseModel = None):
        body = {
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': question}
            ]
        }

        if output_format:
            body['response_format'] = self.make_openai_json_schema(output_format)

        endpoint = f"{self.url}/v1/chat/completions"

        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                response = await client.post(endpoint, headers=self.headers, json=body)
            result = response.json()['choices'][0]['message']['content']
        except KeyError as e:
            print(response.json())
            print(f'llm 서빙 호출 중 keyerror 발생: {e}')
            return None
        except httpx.RequestError as e:
            print(f'llm 서빙 호출 중 오류 발생 : {e}')
            return None

        if output_format:
            return json.loads(result)
        else:
            return result

    def call_all(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?',
                 output_format: BaseModel = None):
        """
        LLM output의 모든 데이터를 내보냅니다.
        """
        body = {
            'messages': [
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': question}
            ]
        }

        if output_format:
            body['response_format'] = self.make_openai_json_schema(output_format)

        endpoint = f"{self.url}/v1/chat/completions"
        response = requests.post(endpoint, headers=self.headers, json=body)
        result = response.json()
        return result

    def call_with_body(self, body: dict, output_format=None):
        """
        LLM output 데이터를 요청합니다. body에 'stream': True가 있으면 제너레이터를 반환합니다.
        """
        if output_format:
            body['response_format'] = self.make_openai_json_schema(output_format)

        endpoint = f"{self.url}/v1/chat/completions"
        is_stream = body.get("stream", False)

        response = requests.post(endpoint, headers=self.headers, json=body, stream=is_stream)
        response.raise_for_status()

        if is_stream:
            def generate():
                for line in response.iter_lines():
                    if not line:
                        continue

                    decoded_line = line.decode('utf-8').strip()

                    # 1. SSE 주석 무시
                    if decoded_line.startswith(':'):
                        continue

                    # 2. 데이터 청크 파싱
                    if decoded_line.startswith('data: '):
                        data_str = decoded_line[6:]  # 'data: ' 제거

                        if data_str == '[DONE]':
                            break

                        try:
                            chunk = json.loads(data_str)
                            if chunk.get("choices"):
                                delta = chunk['choices'][0].get('delta', {})

                                reasoning = delta.get('reasoning', '')
                                content = delta.get('content', '')
                                tool_calls = delta.get('tool_calls')

                                # 1. 추론 (Reasoning) 딕셔너리 반환
                                if reasoning:
                                    yield {"type": "reasoning", "content": reasoning}

                                # 2. 도구 호출 (Tool Calls) 딕셔너리 반환
                                if tool_calls:
                                    yield {"type": "tool_calls", "content": tool_calls}

                                # 3. 일반 답변 (Content) 딕셔너리 반환
                                if content:
                                    yield {"type": "content", "content": content}

                        except json.JSONDecodeError:
                            print(f"JSON 파싱 에러 발생: {data_str}")
                            pass

            return generate()
        else:
            return response.json()

    async def async_call_with_body(self, body: dict, output_format=None):
        if output_format:
            body['response_format'] = self.make_openai_json_schema(output_format)

        endpoint = f"{self.url}/v1/chat/completions"
        is_stream = body.get("stream", False)

        if is_stream:
            async def generate():
                # 조각난 tool_calls를 모아둘 딕셔너리 추가 (index 기준)
                accumulated_tool_calls = {}

                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    async with client.stream("POST", endpoint, headers=self.headers, json=body) as response:
                        response.raise_for_status()
                        async for line in response.aiter_lines():
                            line = line.strip()

                            if not line or line.startswith(':'):
                                continue

                            if line.startswith('data: '):
                                data_str = line[6:]

                                # [DONE] 스트림 종료 처리
                                if data_str == '[DONE]':
                                    # 스트림이 끝날 때, 모아둔 완전한 tool_calls가 있다면 한 번에 딕셔너리로 반환
                                    if accumulated_tool_calls:
                                        final_tool_calls = list(accumulated_tool_calls.values())
                                        yield {"type": "tool_calls", "content": final_tool_calls}
                                    break

                                try:
                                    chunk = json.loads(data_str)
                                    if chunk.get('choices'):
                                        delta = chunk['choices'][0].get('delta', {})

                                        reasoning = delta.get('reasoning', '')
                                        content = delta.get('content', '')
                                        tool_calls_delta = delta.get('tool_calls')

                                        # 1. 추론 (Reasoning) 딕셔너리 반환
                                        if reasoning:
                                            yield {"type": "reasoning", "content": reasoning}

                                        # 2. 도구 호출 (Tool Calls) 병합 로직
                                        if tool_calls_delta:
                                            # 즉시 yield 하지 않고, index를 기준으로 조각들을 병합합니다.
                                            for tc_chunk in tool_calls_delta:
                                                idx = tc_chunk['index']

                                                # 처음 등장하는 index라면 껍데기 생성
                                                if idx not in accumulated_tool_calls:
                                                    accumulated_tool_calls[idx] = {
                                                        "id": tc_chunk.get("id", ""),
                                                        "type": tc_chunk.get("type", "function"),
                                                        "function": {
                                                            "name": tc_chunk.get("function", {}).get("name", ""),
                                                            "arguments": tc_chunk.get("function", {}).get("arguments", "")
                                                        }
                                                    }
                                                # 이미 있는 index라면 arguments 문자열만 이어 붙임 (+=)
                                                else:
                                                    if "function" in tc_chunk and "arguments" in tc_chunk["function"]:
                                                        accumulated_tool_calls[idx]["function"]["arguments"] += \
                                                            tc_chunk["function"]["arguments"]

                                        # 3. 일반 답변 (Content) 딕셔너리 반환
                                        if content:
                                            yield {"type": "content", "content": content}

                                except json.JSONDecodeError:
                                    pass

            return generate()

        else:
            async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                response = await client.post(endpoint, headers=self.headers, json=body)
                response.raise_for_status()
                return response.json()