"""GenOS MCP 서버 호출 클라이언트: 표준 MCP JSON-RPC 2.0.

  POST {genos_url}/api/gateway/mcp/{mcp_server_id}/mcp
  Authorization: Bearer {인증키}   (MCP 서버 상세 > 인증 키. 코드서빙 인증키와 다르다)
  MCP-Protocol-Version: 2025-06-18  (게이트웨이 인식 목록: 2024-11-05 / 2025-03-26 / 2025-06-18 / 2025-11-25 / 2026-07-28)

응답은 JSON 또는 SSE(text/event-stream) 둘 다 올 수 있어 둘 다 파싱한다.
initialize 응답의 Mcp-Session-Id 헤더가 있으면 이후 요청에 실어 보낸다.
"""
import json
import requests
import httpx


class GenOSMCPServer:
    def __init__(self, mcp_server_id: int, bearer_token: str, genos_url: str,
                 protocol_version: str = "2025-06-18"):
        self.url = f"{genos_url.rstrip('/')}/api/gateway/mcp/{mcp_server_id}/mcp"
        self.headers = {
            "Authorization": f"Bearer {bearer_token}",
            "Content-Type": "application/json",
            "Accept": "application/json, text/event-stream",
            "MCP-Protocol-Version": protocol_version,
        }
        self.protocol_version = protocol_version
        self.session_id = None
        self._id = 0

    # ------------------------------------------------------------ 내부
    def _body(self, method: str, params: dict | None = None) -> dict:
        self._id += 1
        b = {"jsonrpc": "2.0", "id": self._id, "method": method}
        if params is not None:
            b["params"] = params
        return b

    def _headers(self) -> dict:
        h = dict(self.headers)
        if self.session_id:
            h["Mcp-Session-Id"] = self.session_id
        return h

    @staticmethod
    def _parse(text: str, content_type: str) -> dict:
        """JSON 또는 SSE(data: 줄) → JSON-RPC 응답 dict. error 면 예외."""
        if "text/event-stream" in content_type:
            text = next((l[5:].strip() for l in text.splitlines()
                         if l.startswith("data:") and l[5:].strip() not in ("", "[DONE]")), "{}")
        out = json.loads(text)
        if "error" in out:
            raise RuntimeError(f"JSON-RPC error: {out['error']}")
        return out.get("result", out)

    def _rpc(self, method: str, params: dict | None = None, timeout: float = 120.0):
        res = requests.post(self.url, headers=self._headers(),
                            json=self._body(method, params), timeout=timeout)
        if res.headers.get("Mcp-Session-Id"):
            self.session_id = res.headers["Mcp-Session-Id"]
        res.raise_for_status()
        return self._parse(res.text, res.headers.get("content-type", ""))

    # ------------------------------------------------------------ 공개
    def initialize(self, client_name: str = "genos-edu") -> dict:
        """세션 시작. GenOS 게이트웨이는 생략해도 tools/* 가 동작하지만 표준 흐름은 이걸 먼저 부른다."""
        return self._rpc("initialize", {
            "protocolVersion": self.protocol_version,
            "capabilities": {},
            "clientInfo": {"name": client_name, "version": "1.0"},
        })

    def list_tools(self) -> list[dict]:
        """tools/list → [{name, description, inputSchema}, ...]. LLM 이 읽는 도구 설명과 동일하다."""
        return self._rpc("tools/list").get("tools", [])

    def call(self, tool_name: str, arguments: dict) -> dict:
        """tools/call → {"content": [{"type": "text", "text": ...}], "isError": bool}"""
        return self._rpc("tools/call", {"name": tool_name, "arguments": arguments}, timeout=300.0)

    def call_text(self, tool_name: str, arguments: dict) -> str:
        """call() 결과에서 text 만 이어 붙여 돌려준다."""
        result = self.call(tool_name, arguments)
        return "".join(c.get("text", "") for c in result.get("content", []) if isinstance(c, dict))

    async def async_call(self, tool_name: str, arguments: dict) -> dict:
        async with httpx.AsyncClient(timeout=300.0) as client:
            res = await client.post(self.url, headers=self._headers(),
                                    json=self._body("tools/call", {"name": tool_name, "arguments": arguments}))
            res.raise_for_status()
            return self._parse(res.text, res.headers.get("content-type", ""))
