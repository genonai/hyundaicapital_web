# GenOS API 실습 자료 (material). 실서버 검증 완료

GenOS 리소스(LLM · 임베딩 · 벡터DB · 워크플로우 · 코드서빙 · MCP · A2A · MinIO · Redis)를 호출하는 **클라이언트** 예제와,
GenOS 안에 올려 실행되는 **서버** 템플릿입니다. `genos-api-193.ipynb` 의 셀과 1:1 로 대응합니다.

## 검증 결과 (2026-09-15, genos.genon.ai 실서버 · `selfcheck.py`)
| 항목 | 결과 | 확인 내용 |
|---|---|---|
| Embedding (서빙 10) | PASS | models · call · call_batch · async, 1024차원 |
| LLM (서빙 1183) | PASS | call · 구조화 출력(json_schema) · 스트리밍 |
| Workflow (6589) | PASS | healthcheck · call · stream_text(token:/result:) · **멀티턴 기억 확인** |
| Code Serving (667) | PASS | health · chat(JSON 봉투) · chat_stream(action→end). HITL 2턴은 아래 ⚠ |
| MCP (721) | PASS | initialize(세션 ID) · tools/list 5개 · tools/call · async |
| A2A (카드 143) | PASS | Agent Card · message/send · extract_text · message/stream. **경로 `/a2a/…` 로 수정 후** |
| Service Router (hc, LLM) | PASS | /v1/chat/completions, 응답 model 로 라우팅 리비전 확인 |
| Weaviate (VDB O745c…) | PASS | 클러스터 내부(port-forward)에서 show_documents 61건 · hybrid · dense · bm25 · 파일명 필터 · to_source_documents |
| MinIO (cdn-api) | PASS | 내부에서 upload → presigned URL, 외부 GET 200 |
| Redis | PASS | ping · set/get 왕복 |
| 서버 템플릿 2종 | PASS | 로컬 기동: /health · `__verify__` · 봉투 · SSE · humanInput · PDF base64 → 청크 |

> ⚠ **HITL 2턴·멀티턴은 외부 인증키 호출로는 재현되지 않습니다.** 게이트웨이가 `x-genos-session-id`·`x-genos-user-id` 를 제거하고 `authorization`·`x-genos-auth-key-id`·`x-genos-agw-session`(요청마다 새 값)만 파드에 넘기는 것을 코드서빙 667 파드 로그로 확인했습니다. 세션 ID 로 상태를 찾는 앱은 "이전 대화를 찾을 수 없습니다" 를 돌려줍니다. **GenOS 앱 채팅에서 테스트**하세요.

> **클라이언트** = 내 PC/코드스페이스에서 GenOS 를 호출하는 코드. **서버** = 코드서빙 컨테이너·워크플로우 Python Step 에 올려 실행되는 코드.

## 파일 한눈에

| 파일 | 구분 | 내용 | v0 → v1 변경 |
|---|---|---|---|
| `GenOSEmbedding.py` | 클라이언트 | 임베딩 서빙 | `models()` 추가 |
| `GenOSLLMServing.py` | 클라이언트 | LLM 서빙 (구조화 출력 · 스트리밍 · reasoning) | 변경 없음 |
| `GenOSWorkflowServing.py` | 클라이언트 | 워크플로우 `/run/v2` | **재작성**. `stream_call()`(token:/result: 파싱) · `healthcheck()` · `new_session()`. 더미 호출로 세션을 얻던 `set_multiturn()` 제거 |
| `GenOSCodeServing.py` | 클라이언트 | 코드서빙 임의 path 호출 | `chat()` · `chat_stream()` 추가. SSE `{"event", "data"}` 프레임 파싱. v2: genportal 과 같은 `x-genos-session-id`·`x-genos-user-id` 헤더 전송 + `new_session()` (외부 호출에선 게이트웨이가 제거. 위 ⚠) |
| `GenOSMCPServer.py` | 클라이언트 | MCP 서버 (JSON-RPC) | **재작성**. `MCP-Protocol-Version` 헤더 · `initialize()` · `list_tools()` · `Mcp-Session-Id` 처리 |
| `GenOSA2A.py` | 클라이언트 | A2A 에이전트 | v2: **경로 `/a2a/…` 로 복원**(v1 의 `/api/gateway/a2a/` 는 이 환경에서 405/HTML. 실측) · `message/send` 기본 · `extract_text()` · 스트림 이벤트명을 `result.kind` 로 |
| `GenOSVectorDB.py` | 클라이언트 | Weaviate 검색 | **재작성**. `vdb_key` 필수(Read Key) · `user_level` 보안등급 필터 · `file_name_pattern`/`folder_path` 필터 · `to_source_documents()` |
| `GenOSMinIOService.py` | 클라이언트 | MinIO 업로드 → Presigned URL | **재작성**. `requests` 기반, `get_doc_resource_url()` 버그 수정(`self`·`aiohttp` 누락) |
| `GenOSCodeServing_main.py` | **서버** | 코드서빙 `/chat` 템플릿 | **신규**. `GenOSCodeServing_service.py` 대체. v2: 비스트리밍 LLM 실패 시 500 → `code 1` 봉투 |
| `GenOSPreprocessor_main.py` | **서버** | 코드서빙 전처리기 `/preprocess` 템플릿 | **신규**. `GenOSTestPreProcessor.py`/`TestPreprocessor.py` 대체. `file_content_base64` 계약 · 현 `GenOSVectorMeta` 필드. v2: 잘못된 base64 도 `code 1` 봉투 |
| `PythonStep*.py` | **서버** | Flowise 워크플로우 Python Step | 런타임 구분 헤더 추가. `PythonStepRAGWorkflow.py` 는 Weaviate 인증(`vdb_key`)·sourceDocuments metadata 보강 |
| `sample_chart.html` | 샘플 | MinIO 실습용 | 변경 없음 |
| `selfcheck.py` | 점검 | 환경변수가 있는 항목만 실제 호출해 PASS/FAIL/SKIP 출력. `--internal`(Weaviate·MinIO·Redis, 클러스터 안에서) · `--local`(서버 템플릿 계약) | **신규** |
| `requirements-preprocessor.txt` | 배포 | `GenOSPreprocessor_main.py` 코드서빙 배포용 requirements (pymupdf · langchain-community · langchain-text-splitters) | **신규** |

**v0 에서 제거한 것**. `GenOSCodeServing_service.py`(`service(config, data)` 진입점은 현재 코드서빙 런타임에 없음), `TestPreprocessor.py`(구버전 중복), `Practice.ipynb`(셀 3개짜리 빈 노트북).

---

## 공통. 주소와 인증키

| 대상 | 경로 | 인증키 발급 위치 |
|---|---|---|
| 모델 서빙(LLM · 임베딩 · VLM) | `{genos_url}/api/gateway/rep/serving/{serving_id}/v1/..` | 모델 서빙 상세 > 인증 키 |
| 워크플로우 | `{genos_url}/api/gateway/workflow/{workflow_id}/run/v2` | 워크플로우 상세 > 인증 키 |
| 코드서빙 | `{genos_url}/api/gateway/code_serving/{code_serving_id}[/{revision_id}]/{path}` | 코드서빙 상세 > 인증 키 |
| MCP 서버 | `{genos_url}/api/gateway/mcp/{mcp_server_id}/mcp` | MCP 서버 상세 > 인증 키 |
| A2A 에이전트 | `{genos_url}/a2a/{agent_card_id}` (**접두어 없음. 실측**) | A2A 에이전트 상세 > 인증 키 |
| 서비스 라우터 | `{genos_url}/api/gateway/service-router/{endpoint}/{path}` | 서비스 라우터 상세 > 인증 키 (**라우터 키**) |
| Weaviate | `llmops-weaviate-service:8080` / gRPC `50051` (내부망) | **벡터DB 상세 > 인증 키 (VDB 전용 Read Key)** |
| MinIO(cdn-api) | `http://llmops-cdn-api-service:8080/minio/..` (내부망) | 없음 |
| Redis | `llmops-redis-service:6379` (내부망) | 없음 |

인증키는 전부 `Authorization: Bearer {키}`. 오류도 **HTTP 200 + `code != 0`** 으로 오는 API 가 많으니 항상 `code` 를 확인하세요.

---

## 1. 임베딩. `GenOSEmbedding.py`
```python
emb = GenOSEmbedding(serving_id=10, bearer_token=TOKEN, genos_url=GENOS_URL)
emb.models()                       # 모델명 · max_model_len
emb.call("문장")[0]["embedding"]    # list[float]
emb.call_batch(["문장1", "문장2"])  # 배치
```

## 2. LLM. `GenOSLLMServing.py`
```python
llm = GenOSLLMServing(serving_id=1183, bearer_token=TOKEN, genos_url=GENOS_URL)
llm.call(system_prompt="한 문장으로.", question="너는 누구니")
llm.call(.., output_format=MyPydanticModel)          # 구조화 출력(json_schema)
for tok in llm.call_with_body({"messages": [..], "stream": True}): .
```
OpenAI SDK 도 그대로 됩니다: `OpenAI(base_url=f"{GENOS_URL}/api/gateway/rep/serving/{id}/v1", api_key=TOKEN)`.

## 3. 워크플로우. `GenOSWorkflowServing.py`
```python
wf = GenOSWorkflowServing(workflow_id=6589, bearer_token=TOKEN, genos_url=GENOS_URL)   # 세션 uuid 자동 생성
wf.healthcheck()
wf.call("1+1은?")["text"]                          # 같은 세션 → 다음 질문이 이전 답을 기억
final = wf.stream_text("방금 답에 3을 더하면?")     # token: 은 print, result: 는 반환
```
스트림은 SSE 가 아니라 `token: ` / `result: ` 접두어 **라인** 스트림입니다.

> **Flowise 명시.** `chatId`·세션 헤더로 히스토리가 자동으로 이어지는 것은 Flowise 노드로 만든 워크플로우입니다. Python Step 로직이나 코드서빙으로 배포한 워크플로우는 세션 ID 를 키로 히스토리를 직접 보관해야 합니다 (`PythonStepRedisHistory.py`, `GenOSCodeServing_main.py` 참고).

## 4. 코드서빙 호출. `GenOSCodeServing.py`
```python
cs = GenOSCodeServing(code_serving_id=667, bearer_token=TOKEN, genos_url=GENOS_URL)   # 세션 uuid 자동 (헤더로 전송)
cs.call("health", method="GET")                    # {"status": "ok"}
cs.chat("안녕!")                                    # {"code": 0, "data": {"text": .}}
for event, data in cs.chat_stream("안녕!"):         # token / sourceDocuments / action / error / end
    ..
```

## 5. 코드서빙 서버 템플릿. `GenOSCodeServing_main.py`  ★
레포 루트에 `main.py` 로 두면 그대로 배포됩니다. 규약:
- `GET /health` 필수(startupProbe) · `POST /chat` `{"question", "stream", "humanInput"?}`
- `stream` 없음 → `{"code": 0, "errMsg": "success", "data": {"text"}}` / `stream: true` → SSE `data: {"event": token|sourceDocuments|action|error|end, "data": .}\n\n`
- `question == "__verify__"` → LLM 없이 `code 0` 즉답(어드민 검증 버튼)
- 설정은 코드에 박지 말고 리비전 > 환경 설정으로. `WEAVIATE_PORT` 처럼 `<서비스명>_PORT` 이름은 K8s 가 `tcp://…` 로 덮어쓰니 피하거나 방어

SSE·HITL(`action`) 상세 규약은 `./계약정리.md` 를 보세요.

## 6. MCP. `GenOSMCPServer.py`
```python
mcp = GenOSMCPServer(mcp_server_id=721, bearer_token=TOKEN, genos_url=GENOS_URL)
mcp.initialize()                                   # 선택(표준 흐름). Mcp-Session-Id 자동 보관
mcp.list_tools()                                   # [{name, description, inputSchema}]
mcp.call_text("add", {"a": 1, "b": 2})             # "3"
```
코드서빙으로 MCP 서버를 만들 땐 `/mcp/list` → `{"code":0,"data":{"tools":[..]}}`, `/mcp/call` → `{"code":0,"data":{"content":[..]}}` **봉투 필수**. `code != 0` 이면 GenOS 가 `errMsg` 를 그대로 사용자에게 올립니다.

## 7. A2A. `GenOSA2A.py`
```python
get_agent_card(agent_card_id, TOKEN, GENOS_URL)
res = call_agent(agent_card_id, TOKEN, "질문", GENOS_URL)      # message/send
extract_text(res); res["result"].get("contextId")             # 멀티턴 키
for ev in call_agent_stream(agent_card_id, TOKEN, "질문", GENOS_URL): .   # message/stream
```

## 8. 벡터DB. `GenOSVectorDB.py`  ★
```python
vdb = GenOSVectorDB(vdb_key=VDB_READ_KEY, idx="K6960b01d…",
                    embedding_serving_id=10, embedding_bearer_token=TOKEN, genos_url=GENOS_URL)
rows = vdb.hybrid_search("근로자의 정의", topk=5, alpha=0.5,
                         user_level=2,                 # 보안등급 필터. 직접 검색은 직접 걸어야 함
                         file_name_pattern="*근로*")   # Filter RAG
docs = vdb.to_source_documents(rows)                   # 채팅 sourceDocuments 규약
```
- **`vdb_key` 없으면 401**. Weaviate 익명 접근이 꺼져 있습니다. 재발급하면 기존 키가 rotate 되어 즉시 무효화됩니다. 읽기 키로 `GET /v1/schema` 를 치면 그 키가 볼 수 있는 컬렉션(=인덱스)만 나옵니다.
- 검증한 VDB 는 `is_encrypted=True` 였고 `bm25_search` 가 일반 단어로는 0건(본문이 암호문), 파일명 토큰으로는 검색됨. 암호화 VDB 는 벡터 검색을 쓰세요.
- 질의 임베딩은 VDB 적재에 쓴 **같은 임베딩 서빙**으로.
- 암호화 적재 VDB 는 `text` 가 암호문 → BM25·커스텀 토큰 미동작, 복호화는 `genos-api-v1.ipynb` §6 참고.

## 9. MinIO. `GenOSMinIOService.py`
```python
minio = GenOSMinIOService(hostname="https://genos.genon.ai")
url = minio.upload_and_get_presigned_url("chart.png")     # 약 2시간 유효
answer = f"결과입니다.\n\n![차트]({url})"                    # token 에 실으면 채팅에 이미지 렌더
```

## 10. 전처리기 서버 템플릿. `GenOSPreprocessor_main.py`  ★
코드서빙으로 배포(`requirements-preprocessor.txt` 를 레포 루트 `requirements.txt` 로) → 컨테이너 서비스 탭 「전처리기로 사용」 → 경로 `/preprocess`.
- 요청 `{"file_path", "params", "file_content_base64", "file_name", "file_size"}`. **`file_content_base64` 를 디코드해 쓴다**(코드서빙 파드는 NFS 미보장)
- 응답 `{"code": 0, "errMsg": "success", "data": [GenOSVectorMeta, ..]}`
- `file_path == "__verify__"` → 즉시 `code 0`
- `GenOSVectorMeta` 는 `extra='allow'`. 커스텀 메타데이터(chunk_id 체계 등)를 더하면 그대로 Weaviate 프로퍼티가 됩니다.

## 11. Flowise Python Step. `PythonStep*.py`
워크플로우 컨테이너(`main_socketio.sio_server`) 안에서 실행되는 스크립트입니다. **코드서빙과 규약이 다릅니다.**
- emit 이벤트: `token` / `result` / `sourceDocuments` / `action` / `agentFlowExecutedData` (컨테이너 `run_util_v2` 가 처리)
- `PythonStepStreaming.py`. 추론(agentFlowExecutedData) · CoT(`<think>`) · 답변 토큰 스트리밍
- `PythonStepRAGWorkflow.py`. VDB(hybrid) + LLM. v1 에서 `vdb_key` 인증 추가, sourceDocuments metadata 를 text 외 전부 넘기도록 수정
- `PythonStepRedisHistory.py`. `llmops-redis-service:6379` 멀티턴 히스토리
- `PythonStepAdvancedRAGWorkflow.py`. 라우팅 + MCP retriever + Redis 히스토리

---

## 이 자료가 참조하는 GenOS 소스 (계약 근거)
| 계약 | 근거 |
|---|---|
| 코드서빙 런타임(main.py·/health·env) | `container-services/code-serving/scripts/entrypoint.sh`, `init.sh` |
| 코드서빙 /chat body·SSE 처리 | `genportal-api/src/service/agent/agent_service.py` |
| `__verify__` | `admin-front/src/views/serving/code/ContainerServiceTab.js` |
| MCP 봉투·프로토콜 버전 | `admin-api/src/service/mcp/mcp_server_service.py`, `gateway-api/src/utils/mcp_spec.py` |
| 전처리기 코드서빙 계약 | `preprocess-api/src/util/run_util.py` (`_attach_file_content_base64`) |
| GenOSVectorMeta 필드 | `code-serving-resources/doc-parser-preprocessor/preprocessor.py` |
| VDB Read Key(RBAC) | `admin-api/src/service/data/vdb_credential_service.py` |
| A2A 경로·method | `admin-api/src/router/a2a/a2a_protocol_router.py`. 실제 노출 경로는 인그레스 기준 `/a2a/…` (실측) |
| 워크플로우 스트림 token:/result: | `container-services/workflow/src/util/run_util_v2.py` |
| MinIO 라우트 | `cdn-api/src/router/minio_router.py` |
