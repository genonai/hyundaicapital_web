"""GenOS 워크플로우 실행 클라이언트.

  POST {genos_url}/api/gateway/workflow/{workflow_id}/run/v2
  GET  {genos_url}/api/gateway/workflow/{workflow_id}/healthcheck
  Authorization: Bearer {인증키}   (워크플로우 상세 > 인증 키)

응답 봉투 {"code": 0, "errMsg": "success", "data": {"text", "sourceDocuments", "chatId"/"sessionId"}}
오류도 HTTP 200 으로 오므로 code 를 확인해야 한다.

멀티턴은 body 의 chatId 로 잇는다. 같은 값을 계속 보내면 그 대화의 히스토리가 이어진다.
(헤더 x-genos-session-id 는 외부 인증키 호출에서 게이트웨이가 제거하므로 chatId 가 유일한 수단이다.)

스트리밍 응답 형식은 워크플로우를 만든 Flowise 버전에 따라 두 가지다.
  Flowise 1.8.0  →  `token: 조각` / `result: {...}`  라인 스트림
  그 외(2.2.3·3.0.0) →  `data: {"event": "token"|"result", "data": ...}` SSE 프레임
아래 stream_call() 은 둘 다 파싱한다.
"""
import json
import uuid
import requests
import httpx


class GenOSWorkflowServing:
    def __init__(self, workflow_id: int, bearer_token: str, genos_url: str, session_id: str | None = None):
        self.url = f"{genos_url.rstrip('/')}/api/gateway/workflow/{workflow_id}"
        self.token = bearer_token
        self.session_id = session_id or str(uuid.uuid4())     # 미지정이면 새 세션

    def _headers(self) -> dict:
        return {"Authorization": f"Bearer {self.token}"}

    def _body(self, question: str, stream: bool = False, override_config: dict | None = None) -> dict:
        body = {"question": question, "chatId": self.session_id, "stream": stream}
        if override_config:
            body["overrideConfig"] = override_config
        return body

    def new_session(self) -> str:
        """새 대화 시작. 이후 호출은 이 세션의 히스토리를 이어간다."""
        self.session_id = str(uuid.uuid4())
        return self.session_id

    def healthcheck(self) -> dict:
        return requests.get(f"{self.url}/healthcheck", headers=self._headers(), timeout=10).json()

    def call(self, question: str, override_config: dict | None = None, timeout: float = 120.0) -> dict:
        """비스트리밍. data.text / data.sourceDocuments 반환."""
        res = requests.post(f"{self.url}/run/v2", headers=self._headers(),
                            json=self._body(question, False, override_config), timeout=timeout).json()
        if res.get("code") != 0:
            raise RuntimeError(f"워크플로우 오류: {res.get('errMsg')}")
        return res["data"]

    def stream_call(self, question: str, override_config: dict | None = None, timeout: float = 120.0):
        """토큰을 yield 하고, 끝나면 최종 result dict 를 StopIteration.value 로 돌려준다.
        for 문으로 소비하면 토큰만 받고, 최종본이 필요하면 아래 stream_text() 를 쓴다.
        `token: ` 라인(Flowise 1.8.0)과 `data: {"event": ...}` SSE(그 외) 를 모두 받는다."""
        final = None
        with requests.post(f"{self.url}/run/v2", headers=self._headers(), stream=True, timeout=timeout,
                           json=self._body(question, True, override_config)) as res:
            for raw in res.iter_lines():
                if not raw:
                    continue
                line = raw.decode()
                if line.startswith("token: "):
                    yield line[7:]
                elif line.startswith("result: "):
                    final = json.loads(line[8:])
                elif line.startswith("data: "):
                    payload = line[6:]
                    if payload == "[DONE]":
                        continue
                    try:
                        frame = json.loads(payload)
                    except json.JSONDecodeError:
                        continue
                    event, data = frame.get("event"), frame.get("data")
                    if event == "token" and isinstance(data, str):
                        yield data
                    elif event == "result":
                        final = data
        return final

    def stream_text(self, question: str, on_token=print) -> dict | None:
        """토큰은 on_token 콜백으로 흘리고 최종 result 를 반환."""
        gen = self.stream_call(question)
        try:
            while True:
                on_token(next(gen))
        except StopIteration as stop:
            return stop.value

    async def async_call(self, question: str, override_config: dict | None = None, timeout: float = 120.0) -> dict:
        async with httpx.AsyncClient(timeout=timeout) as client:
            res = (await client.post(f"{self.url}/run/v2", headers=self._headers(),
                                     json=self._body(question, False, override_config))).json()
        if res.get("code") != 0:
            raise RuntimeError(f"워크플로우 오류: {res.get('errMsg')}")
        return res["data"]
