"""material 동작 점검: 환경변수가 있는 항목만 실행, 없으면 SKIP.

  사용:  python selfcheck.py            (게이트웨이 API: 어디서든)
         python selfcheck.py --internal (Weaviate·MinIO·Redis: 코드스페이스/코드서빙 등 클러스터 내부에서)
         python selfcheck.py --local    (서버 템플릿 2종을 프로세스 안에서 기동해 계약 확인)

  환경변수:
    GENOS_URL (기본 https://genos.genon.ai)
    EMB_SERVING_ID · EMB_TOKEN          LLM_SERVING_ID · LLM_TOKEN
    WORKFLOW_ID · WF_TOKEN              CODE_SERVING_ID · CS_TOKEN
    MCP_SERVER_ID · MCP_TOKEN           A2A_AGENT_CARD_ID · A2A_TOKEN
    ROUTER_ENDPOINT · ROUTER_TOKEN · ROUTER_TYPE(llm|embedding|code)
    VDB_KEY · VDB_INDEX (+EMB_*)        WEAVIATE_HOST(기본 llmops-weaviate-service)
    CDN_URL(기본 http://llmops-cdn-api-service:8080) · PUBLIC_HOSTNAME(기본 GENOS_URL)
    REDIS_HOST(기본 llmops-redis-service)
"""
import asyncio, json, os, sys, time, traceback, uuid

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
GENOS_URL = os.getenv("GENOS_URL", "https://genos.genon.ai")
RESULTS = []


def check(name, fn, *need):
    missing = [k for k in need if not os.getenv(k)]
    if missing:
        RESULTS.append((name, "SKIP", "env 없음: " + ", ".join(missing))); return
    t = time.time()
    try:
        msg = fn() or ""
        RESULTS.append((name, "PASS", f"{msg}  ({time.time()-t:.1f}s)"))
    except Exception as e:
        RESULTS.append((name, "FAIL", f"{type(e).__name__}: {str(e)[:160]}"))
        if os.getenv("SELFCHECK_TRACE"): traceback.print_exc()


def env_int(k): return int(os.getenv(k))
def short(x, n=70): s = json.dumps(x, ensure_ascii=False) if not isinstance(x, str) else x; return s[:n].replace("\n", " ")


# ── 게이트웨이 API ─────────────────────────────────────────────────────────────
def t_embedding():
    from GenOSEmbedding import GenOSEmbedding
    e = GenOSEmbedding(serving_id=env_int("EMB_SERVING_ID"), bearer_token=os.getenv("EMB_TOKEN"), genos_url=GENOS_URL)
    m = e.models(); v1 = e.call("현대캐피탈 오토론"); vb = e.call_batch(["문장 하나", "문장 둘"])
    assert len(vb) == 2 and len(vb[0]["embedding"]) == len(v1[0]["embedding"])
    va = asyncio.run(e.async_call("비동기"))
    return f"model={m['data'][0]['id']} dim={len(v1[0]['embedding'])} batch=2 async=ok"


def t_llm():
    from GenOSLLMServing import GenOSLLMServing
    from pydantic import BaseModel
    l = GenOSLLMServing(serving_id=env_int("LLM_SERVING_ID"), bearer_token=os.getenv("LLM_TOKEN"), genos_url=GENOS_URL)
    a = l.call(system_prompt="한 단어로 답해.", question="1+1은?")
    class Out(BaseModel):
        answer: int
        reason: str
    s = l.call(system_prompt="JSON 으로만 답해.", question="17 곱하기 23은?", output_format=Out)
    toks = []
    for tk in l.call_with_body({"messages": [{"role": "user", "content": "안녕이라고만 말해"}], "stream": True, "max_tokens": 64}):
        toks.append(tk)
        if len(toks) >= 5: break
    return f"call='{short(a, 30)}' structured={short(s, 40)} stream_tokens={len(toks)}"


def t_workflow():
    from GenOSWorkflowServing import GenOSWorkflowServing
    w = GenOSWorkflowServing(workflow_id=env_int("WORKFLOW_ID"), bearer_token=os.getenv("WF_TOKEN"), genos_url=GENOS_URL)
    h = w.healthcheck(); r1 = w.call("내 이름은 홍길동이야. 기억해줘.")
    r2 = w.stream_text("내 이름이 뭐라고 했지?", on_token=lambda t: None)
    txt2 = (r2 or {}).get("text", "") if isinstance(r2, dict) else str(r2)
    return f"health={short(h, 20)} turn1='{short(r1.get('text',''), 25)}' turn2='{short(txt2, 40)}' 멀티턴={'OK' if '홍길동' in txt2 else '미확인'}"


def t_code_serving():
    from GenOSCodeServing import GenOSCodeServing
    c = GenOSCodeServing(code_serving_id=env_int("CODE_SERVING_ID"), bearer_token=os.getenv("CS_TOKEN"), genos_url=GENOS_URL)
    h = c.call("health", method="GET"); r = c.chat("안녕! 한 문장으로 자기소개 해줘")
    assert r.get("code") == 0, r
    events = [ev for ev, _ in c.chat_stream("안녕! 한 문장으로 자기소개 해줘")]
    assert events[-1] == "end" and ("token" in events or "action" in events), events   # HITL 앱은 첫 응답이 action
    return f"health={short(h, 20)} chat='{short(r['data'].get('text',''), 30)}' sse_events={sorted(set(events))} session={c.session_id[:8]}"


def t_mcp():
    from GenOSMCPServer import GenOSMCPServer
    m = GenOSMCPServer(mcp_server_id=env_int("MCP_SERVER_ID"), bearer_token=os.getenv("MCP_TOKEN"), genos_url=GENOS_URL)
    init = m.initialize(); tools = m.list_tools(); assert tools
    t0 = tools[0]; args = {k: 3 for k in (t0.get("inputSchema") or {}).get("required", [])}
    out = m.call_text(t0["name"], args)
    return f"server={init.get('serverInfo',{}).get('name')} tools={[t['name'] for t in tools][:6]} call({t0['name']})='{short(out, 25)}'"


def t_a2a():
    import GenOSA2A as a
    cid, tok = env_int("A2A_AGENT_CARD_ID"), os.getenv("A2A_TOKEN")
    card = a.get_agent_card(cid, tok, GENOS_URL); assert card, "agent card 없음"
    res = a.call_agent(cid, tok, "안녕! 한 문장으로 자기소개 해줘", GENOS_URL)
    txt = a.extract_text(res)
    n = 0
    for ev in a.call_agent_stream(cid, tok, "안녕", GENOS_URL):
        n += 1
        if n >= 3: break
    return f"card='{card.get('name')}' answer='{short(txt, 40)}' stream_events>={n}"


def t_router():
    import requests
    url = f"{GENOS_URL}/api/gateway/service-router/{os.getenv('ROUTER_ENDPOINT')}"
    h = {"Authorization": f"Bearer {os.getenv('ROUTER_TOKEN')}"}
    kind = os.getenv("ROUTER_TYPE", "llm")
    if kind == "llm":
        r = requests.post(f"{url}/v1/chat/completions", headers=h, json={"messages": [{"role": "user", "content": "한 단어로: 1+1?"}], "max_tokens": 32}, timeout=60).json()
        return f"model={r.get('model')} answer='{short(r['choices'][0]['message']['content'], 20)}'"
    if kind == "embedding":
        r = requests.post(f"{url}/v1/embeddings", headers=h, json={"input": ["테스트"]}, timeout=30).json()
        return f"dim={len(r['data'][0]['embedding'])}"
    r = requests.post(f"{url}/chat", headers=h, json={"question": "안녕"}, timeout=120).json()
    assert r.get("code") == 0, r
    return f"code_serving answer='{short(r['data'].get('text',''), 30)}'"


# ── 클러스터 내부 ──────────────────────────────────────────────────────────────
def t_vdb():
    from GenOSVectorDB import GenOSVectorDB
    v = GenOSVectorDB(vdb_key=os.getenv("VDB_KEY"), idx=os.getenv("VDB_INDEX"),
                      embedding_serving_id=env_int("EMB_SERVING_ID"), embedding_bearer_token=os.getenv("EMB_TOKEN"),
                      genos_url=GENOS_URL, weaviate_host=os.getenv("WEAVIATE_HOST", "llmops-weaviate-service"),
                      http_port=int(os.getenv("WEAVIATE_HTTP_PORT", "8080")), grpc_port=int(os.getenv("WEAVIATE_GRPC_PORT", "50051")))
    try:
        docs = v.show_documents(); q = os.getenv("VDB_QUERY", "근로자의 정의")
        hy = v.hybrid_search(q, topk=3, user_level=int(os.getenv("VDB_USER_LEVEL", "99")))
        de = v.dense_search(q, topk=2); bm = v.bm25_search(q, topk=2)
        fn = v.search_from_file_name(q, file_name_pattern=f"*{docs[0].split('.')[0][:2]}*", topk=2) if docs else []
        sd = v.to_source_documents(hy)
        assert not hy or ("pageContent" in sd[0] and "metadata" in sd[0])
        return f"docs={len(docs)} hybrid={len(hy)} dense={len(de)} bm25={len(bm)} file_filter={len(fn)} sourceDocs_keys={sorted(sd[0]['metadata'].keys())[:5] if sd else []}"
    finally:
        v.close()


def t_minio():
    from GenOSMinIOService import GenOSMinIOService
    svc = GenOSMinIOService(hostname=os.getenv("PUBLIC_HOSTNAME", GENOS_URL), cdn_url=os.getenv("CDN_URL", "http://llmops-cdn-api-service:8080")) \
        if "cdn_url" in GenOSMinIOService.__init__.__code__.co_varnames else GenOSMinIOService(hostname=os.getenv("PUBLIC_HOSTNAME", GENOS_URL))
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sample_chart.html")
    url = svc.upload_and_get_presigned_url(path)
    assert url.startswith("http"), url
    import requests; st = requests.get(url, timeout=30).status_code
    return f"presigned={short(url, 60)} GET={st}"


def t_redis():
    import redis
    r = redis.Redis(host=os.getenv("REDIS_HOST", "llmops-redis-service"), port=int(os.getenv("REDIS_PORT", "6379")), db=0, socket_timeout=5)
    k = f"selfcheck:{uuid.uuid4()}"; r.set(k, json.dumps([{"role": "user", "content": "hi"}]), ex=60)
    v = json.loads(r.get(k)); r.delete(k)
    return f"ping={r.ping()} roundtrip={v[0]['content']}"


# ── 서버 템플릿 (로컬 프로세스 안) ─────────────────────────────────────────────
def t_local_templates():
    import base64
    from fastapi.testclient import TestClient
    import GenOSCodeServing_main as cs, GenOSPreprocessor_main as pp
    c = TestClient(cs.app)
    assert c.get("/health").json() == {"status": "ok"}
    assert c.post("/chat", json={"question": "__verify__"}).json()["code"] == 0
    r = c.post("/chat", json={"question": "안녕"}).json(); assert "code" in r                     # LLM 없어도 봉투
    with c.stream("POST", "/chat", json={"question": "", "stream": True, "humanInput": {"type": "proceed", "interactionId": "x", "action": "submit", "values": {"selected": ["a"]}}}) as s:
        frames = [l for l in s.iter_lines() if l.startswith("data: ")]
    evs = [json.loads(f[6:])["event"] for f in frames]; assert evs[-1] == "end" and "token" in evs, evs
    p = TestClient(pp.app)
    assert p.get("/health").json() == {"status": "ok"}
    assert p.post("/preprocess", json={"file_path": "__verify__", "params": {}}).json()["code"] == 0
    bad = p.post("/preprocess", json={"file_path": "x.pdf", "params": {}, "file_content_base64": "!!", "file_name": "x.pdf"}).json(); assert bad["code"] == 1
    pdf = os.getenv("SELFCHECK_PDF")
    msg = f"code_serving: health/verify/envelope/sse OK · preprocessor: health/verify/error OK"
    if pdf and os.path.exists(pdf):
        b = open(pdf, "rb").read()
        r = p.post("/preprocess", json={"file_path": "/nfs/x.pdf", "params": {"chunk_size": 300}, "file_content_base64": base64.b64encode(b).decode(), "file_name": os.path.basename(pdf), "file_size": len(b)}).json()
        assert r["code"] == 0 and r["data"], r; msg += f" · pdf chunks={len(r['data'])}"
    return msg


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    if mode == "--internal":
        check("VectorDB (Weaviate)", t_vdb, "VDB_KEY", "VDB_INDEX", "EMB_SERVING_ID", "EMB_TOKEN")
        check("MinIO (cdn-api)", t_minio)
        check("Redis", t_redis)
    elif mode == "--local":
        check("서버 템플릿 (CodeServing_main · Preprocessor_main)", t_local_templates)
    else:
        check("Embedding", t_embedding, "EMB_SERVING_ID", "EMB_TOKEN")
        check("LLM", t_llm, "LLM_SERVING_ID", "LLM_TOKEN")
        check("Workflow", t_workflow, "WORKFLOW_ID", "WF_TOKEN")
        check("Code Serving", t_code_serving, "CODE_SERVING_ID", "CS_TOKEN")
        check("MCP", t_mcp, "MCP_SERVER_ID", "MCP_TOKEN")
        check("A2A", t_a2a, "A2A_AGENT_CARD_ID", "A2A_TOKEN")
        check("Service Router", t_router, "ROUTER_ENDPOINT", "ROUTER_TOKEN")
    w = max(len(n) for n, _, _ in RESULTS)
    for n, st, msg in RESULTS:
        print(f"[{st}] {n:<{w}}  {msg}")
    sys.exit(1 if any(st == "FAIL" for _, st, _ in RESULTS) else 0)
