"""[Flowise 워크플로우 Python Step 전용]
이 스크립트는 워크플로우 컨테이너(main_socketio.sio_server) 안에서 실행된다.
  - 화면까지 전달되는 emit 이벤트: token / sourceDocuments / agentReasoning / agentFlowExecutedData / error
  - result 는 답변 텍스트 누적용이다. token 을 이미 흘렸으면 폐기되므로 출처는 sourceDocuments 로 따로 emit 한다.
  - HITL(action)은 이 경로에서 전달되지 않는다. 필요하면 코드서빙으로 만든다 → GenOSCodeServing_main.py
  - 코드서빙(FastAPI)에서는 이 방식이 아니라 SSE `data: {"event": "token", ...}` 프레임을 쓴다.
"""
from util.genos_utils import genos_import

genos_import('requests')
genos_import('httpx')
genos_import(package_name="weaviate", version='4.11.1', install_name='weaviate-client')

import requests
import httpx
from pydantic import BaseModel, ConfigDict
import json
import weaviate
from weaviate.classes.query import Filter
import os


async def run(data: dict) -> dict:
    class GenOSEmbedding:
        def __init__(self, serving_id: str, bearer_token: str, genos_url: str):
            self.serving_id = serving_id
            self.url = f"{genos_url}/api/gateway/rep/serving/{serving_id}"
            self.headers = dict(Authorization=f"Bearer {bearer_token}")
            if serving_id and bearer_token:
                print(f'embedding model: {serving_id}번과 토큰이 입력되었습니다.')
            else:
                print('serving id 혹은 인증키가 입력되지 않았습니다.')

        def call(self, question: str = '안녕?'):

            body = {
                "input": [question]
            }
            endpoint = f"{self.url}/v1/embeddings"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            vector = result['data']
            return vector

        def call_batch(self, question: list = ['안녕?', "넌 누구니?"]):
            body = {
                "input": question
            }
            endpoint = f"{self.url}/v1/embeddings"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            vector = result['data']
            return vector

        async def async_call(self, question='안녕?'):
            body = {
                "input": question
            }
            endpoint = f"{self.url}/v1/embeddings"
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    response = await client.post(endpoint, headers=self.headers, json=body)
                    result = response.json()
                    vector = result['data']

            except KeyError as e:
                print(response.json())
                print(f'embedding 서빙 호출 중 keyerror 발생: {e}')
                return None
            except httpx.RequestError as e:
                print(f'embedding 서빙 호출 중 오류 발생 : {e}')
                return None
            return vector

        async def async_call_batch(self, question: list = ['안녕?', "넌 누구니?"]):
            body = {
                "input": question
            }
            endpoint = f"{self.url}/v1/embeddings"
            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    response = await client.post(endpoint, headers=self.headers, json=body)
                    result = response.json()
                    vector = result['data']

            except KeyError as e:
                print(response.json())
                print(f'embedding 서빙 호출 중 keyerror 발생: {e}')
                return None
            except httpx.RequestError as e:
                print(f'embedding 서빙 호출 중 오류 발생 : {e}')
                return None
            return vector

    class GenOSLLMServing:
        def __init__(self, serving_id: int, bearer_token: str, genos_url: str):
            self.serving_id = serving_id
            self.url = f"{genos_url}/api/gateway/rep/serving/{serving_id}"
            self.headers = dict(Authorization=f"Bearer {bearer_token}")
            self.endpoint = f"{self.url}/v1/models"
            if serving_id and bearer_token:
                print(f'model: {serving_id}번과 토큰이 입력되었습니다.')
            else:
                print('serving id 혹은 인증키가 입력되지 않았습니다.')

        def make_openai_json_schema(self, model: type[BaseModel]) -> dict:
            if not model.model_config:
                model.model_config = ConfigDict(extra='forbid')
            return {
                "type": "json_schema",
                "json_schema": {
                    "name": model.__name__,  # 클래스 이름 자동 반영
                    "strict": True,
                    "schema": model.model_json_schema()
                }
            }

        def call(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?',
                 output_format: BaseModel = None):
            """
            LLM output의 text만 내보냅니다.
            """
            body = {
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            try:
                response = requests.post(endpoint, headers=self.headers, json=body, stream=True)
                result = response.json()['choices'][0]['message']['content']
            except KeyError as e:
                print(response.json())
                print(f'llm 서빙 호출 중 keyerror 발생: {e}')
                return None
            except requests.exceptions.RequestException as e:
                print(f'llm 서빙 호출 중 오류 발생 : {e}')
                return None

            if output_format:
                return json.loads(result)
            else:
                return result

        async def async_call(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?',
                             output_format: BaseModel = None):
            body = {
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"

            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    response = await client.post(endpoint, headers=self.headers, json=body)
                result = response.json()['choices'][0]['message']['content']
            except KeyError as e:
                print(response.json())
                print(f'llm 서빙 호출 중 keyerror 발생: {e}')
                return None
            except httpx.RequestError as e:
                print(f'llm 서빙 호출 중 오류 발생 : {e}')
                return None

            if output_format:
                return json.loads(result)
            else:
                return result

        def call_all(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?',
                     output_format: BaseModel = None):
            """
            LLM output의 모든 데이터를 내보냅니다.
            """
            body = {
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            return result

        def call_with_body(self,
                           body={
                               'messages': [
                                   {'role': 'system', 'content': '당신은 유용한 어시스턴트입니다.'},
                                   {'role': 'user', 'content': '안녕?'}
                               ]
                           },
                           output_format: BaseModel = None):
            """
            LLM output의 모든 데이터를 내보냅니다.
            """
            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            return result

        async def async_call_with_body(self,
                                       body: dict = {
                                           'messages': [
                                               {'role': 'system', 'content': '당신은 유용한 어시스턴트입니다.'},
                                               {'role': 'user', 'content': '안녕?'}
                                           ]
                                       },
                                       output_format: BaseModel = None):
            """
            LLM output의 모든 데이터를 비동기로 요청합니다.
            """
            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"

            async with httpx.AsyncClient() as client:
                response = await client.post(endpoint, headers=self.headers, json=body)
                response.raise_for_status()  # 오류 발생 시 예외 발생
                return response.json()

    class GenOSVectorDB:
        def __init__(self, weaviate_ip: str,
                     vdb_key: str,
                     http_port: int,
                     grpc_port: int,
                     idx: str,
                     embedding_serving_id: int,
                     embedding_bearer_token: str,
                     embedding_genos_url: str):
            try:
                from weaviate.classes.init import Auth
                self.client = weaviate.connect_to_custom(
                    http_host=weaviate_ip,
                    http_port=http_port,
                    http_secure=False,
                    grpc_host=weaviate_ip,
                    grpc_port=grpc_port,
                    grpc_secure=False,
                    auth_credentials=Auth.api_key(vdb_key),   # ★ VDB 전용 Read Key (벡터DB 상세 > 인증 키). 없으면 401
                    skip_init_checks=True,
                )
                print("weaviate에 접속하였습니다.")
            except Exception as e:
                print(f'Weaviate 접속 중 오류 발생, 접속 정보를 확인하세요. {e}')

            self.collection = 'vdb collection이 설정되지 않았습니다.'
            if not idx:
                print('벡터 인덱스가 설정되지 않았습니다. 벡터 인덱스를 설정하세요.')

            else:
                self.collection = self.client.collections.get(idx)
                print('VDB를 설정했습니다.')
                # print('----VDB 내부 property sample 3개----')
                # for i, obj in enumerate(self.collection.iterator()):
                #     print(obj.properties['text'])
                #     if i == 2:
                #         break
            print(f'유사도 검색을 위한 임베딩 모델로 {embedding_serving_id}번 임베딩 모델을 사용합니다.')
            self.emb = GenOSEmbedding(serving_id=embedding_serving_id, bearer_token=embedding_bearer_token,
                                      genos_url=embedding_genos_url)

        def dense_search(self, query: str, topk=4):
            vector = self.emb.call(query)[0]['embedding']
            results = [i.properties for i in self.collection.query.near_vector(near_vector=vector, limit=topk).objects]
            return results

        def bm25_search(self, query: str, topk=4):
            results = [i.properties for i in self.collection.query.bm25(query, limit=topk).objects]
            return results

        def hybrid_search(self, query: str, topk: int = 4, alpha: float = 0.5):
            vector = self.emb.call(query)[0]['embedding']
            results = [i.properties for i in self.collection.query.hybrid(query=query,
                                                                          vector=vector,
                                                                          alpha=alpha, limit=topk).objects]
            return results

        def show_documents(self):
            query_return = self.collection.query.fetch_objects(
                limit=10000,
                return_properties=['file_name']
            )
            file_names = list(dict.fromkeys([i.properties['file_name'] for i in query_return.objects]))
            return file_names

        def search_from_file_name(self, query: str, file_name_pattern, topk=4, alpha=0.5):
            vector = self.emb.call(query)[0]['embedding']
            query_return = self.collection.query.hybrid(
                query=query,
                limit=topk,
                filters=Filter.by_property("file_name").like(file_name_pattern),
                vector=vector
            )
            results = [i.properties for i in query_return.objects]
            return results

        def close(self):
            self.client.close()
            print("Weaviate 접속을 종료하였습니다.")

    GENOS_URL = os.getenv("GENOS_URL", "")
    EMBEDDING_SERVING_ID = os.getenv("EMBEDDING_SERVING_ID", "")
    EMBEDDING_BEARER_TOKEN = os.getenv("EMBEDDING_BEARER_TOKEN", "")
    WEAVIATE_URL = os.getenv("WEAVIATE_URL", "llmops-weaviate-service")
    WEAVIATE_INDEX = os.getenv("WEAVIATE_INDEX", "")
    WEAVIATE_VDB_KEY = os.getenv("WEAVIATE_VDB_KEY", "")   # 벡터DB 상세 > 인증 키 (Read Key)
    WEAVIATE_HTTP_PORT = int(os.getenv("WEAVIATE_HTTP_PORT", "8080"))
    WEAVIATE_GRPC_PORT = int(os.getenv("WEAVIATE_GRPC_PORT", "50051"))
    LLM_SERVING_ID = os.getenv("LLM_SERVING_ID", "")
    LLM_BEARER_TOKEN = os.getenv("LLM_BEARER_TOKEN", "")

    vdb = GenOSVectorDB(weaviate_ip=WEAVIATE_URL,
                        vdb_key=WEAVIATE_VDB_KEY,
                        http_port=WEAVIATE_HTTP_PORT,
                        grpc_port=WEAVIATE_GRPC_PORT,
                        idx=WEAVIATE_INDEX,
                        embedding_serving_id=EMBEDDING_SERVING_ID,
                        embedding_bearer_token=EMBEDDING_BEARER_TOKEN,
                        embedding_genos_url=GENOS_URL
                        )
    llm = GenOSLLMServing(serving_id=LLM_SERVING_ID,
                          bearer_token=LLM_BEARER_TOKEN,
                          genos_url=GENOS_URL)

    question = data.get('question', "")
    retrieved_documents = vdb.hybrid_search(query=question)
    system_prompt = f"""검색된 문서를 바탕으로 질문에 대답하세요.
    검색된 문서 : {retrieved_documents}"""
    answer = llm.call(system_prompt=system_prompt, question=question)
    data['text'] = answer
    sourceDocuments = [
        {
            "pageContent": i['text'],
            # text 외 프로퍼티는 전부 넘긴다: doc_id(휴지통 제외)·security_level(등급 필터)·chunk_bboxes(뷰어 하이라이트)를 화이트리스트로 고르면 빠진다
            "metadata": {k: v for k, v in i.items() if k != 'text' and v is not None}
        } for i in retrieved_documents
    ]
    data['sourceDocuments'] = sourceDocuments
    return data

