"""코드서빙 **전처리기** 서버 템플릿: 레포 루트 main.py 로 두고 컨테이너 서비스 탭에서 「전처리기로 사용」.

플랫폼 계약(preprocess-api → 코드서빙 게이트웨이):
  요청  POST {preprocessor_path}   기본 /preprocess
        {"file_path": str, "params": dict,
         "file_content_base64": str, "file_name": str, "file_size": int}
        파일을 받는 방법은 두 가지다. 이 템플릿은 base64 를 쓴다.
          file_content_base64  preprocess-api 가 파일을 읽어 동봉해 준다. 디코드해 임시 파일로 저장한다.
          file_path            코드서빙 파드에도 /nfs-root 가 마운트돼 있어 직접 읽어도 된다.
                               (공식 doc-parser-preprocessor 는 이 방식을 쓴다)
  응답  {"code": 0, "errMsg": "success", "data": [GenOSVectorMeta, ...]}   (실패도 HTTP 200 + code != 0)
  검증  어드민 「검증」버튼은 file_path="__verify__" 를 보낸다 → 즉시 code 0

GenOSVectorMeta 필드는 doc-parser-preprocessor(code-serving-resources) 의 현재 스키마와 맞춘다.
extra='allow' 라 커스텀 메타데이터(chunk_id 체계 등)를 자유롭게 더할 수 있다: 그대로 Weaviate 프로퍼티가 된다.
"""
import base64
import os
import tempfile
from collections import defaultdict
from datetime import datetime
from typing import Optional

from fastapi import FastAPI, Request
from pydantic import BaseModel

app = FastAPI()


class GenOSVectorMeta(BaseModel):
    class Config:
        extra = "allow"

    text: str = None                 # 검색·임베딩 대상 본문
    n_char: int = None
    n_word: int = None
    n_line: int = None
    i_page: int = None               # 시작 페이지(1-base)  → 출처 카드·뷰어
    e_page: int = None               # 끝 페이지
    i_chunk_on_page: int = None
    n_chunk_of_page: int = None
    i_chunk_on_doc: int = None
    n_chunk_of_doc: int = None
    n_page: int = None
    reg_date: str = None
    chunk_bboxes: str = None         # JSON 문자열 [{"page", "bbox": {"l","t","r","b","coord_origin"}}] → 뷰어 하이라이트
    media_files: str = None          # JSON 문자열 → 출처 썸네일
    created_date: Optional[int] = None   # YYYYMMDD
    authors: Optional[str] = None
    title: Optional[str] = None


class DocumentProcessor:
    """PDF → 페이지 로드 → 재귀 문자 분할 → GenOSVectorMeta. 다른 포맷은 load_documents 의 로더만 바꾼다."""

    def load_documents(self, file_path: str, **kwargs):
        from langchain_community.document_loaders import PyMuPDFLoader
        return PyMuPDFLoader(file_path).load()

    def split_documents(self, documents, **kwargs):
        from langchain_text_splitters import RecursiveCharacterTextSplitter
        splitter = RecursiveCharacterTextSplitter(
            chunk_size=int(kwargs.get("chunk_size") or 800),
            chunk_overlap=int(kwargs.get("chunk_overlap") or 100))
        chunks = [c for c in splitter.split_documents(documents) if c.page_content.strip()]
        if not chunks:
            raise ValueError("Empty document")
        for c in chunks:
            c.metadata["page"] = int(c.metadata.get("page", 0)) + 1     # PyMuPDF 는 0-base
        return chunks

    def compose_vectors(self, chunks, file_path: str, **kwargs) -> list[dict]:
        n_page = max(c.metadata["page"] for c in chunks)
        per_page = defaultdict(list)
        for c in chunks:
            per_page[c.metadata["page"]].append(c)
        today = datetime.now()
        out = []
        for i_doc, c in enumerate(chunks):
            page = c.metadata["page"]
            out.append(GenOSVectorMeta(
                text=c.page_content,
                n_char=len(c.page_content), n_word=len(c.page_content.split()),
                n_line=len(c.page_content.splitlines()),
                i_page=page, e_page=page,
                i_chunk_on_page=per_page[page].index(c), n_chunk_of_page=len(per_page[page]),
                i_chunk_on_doc=i_doc, n_chunk_of_doc=len(chunks), n_page=n_page,
                # reg_date 는 Weaviate DATE 프로퍼티라 RFC3339 여야 한다. 끝의 Z 를 빼면 적재가 실패한다.
                reg_date=today.isoformat(timespec="seconds") + "Z",
                created_date=int(today.strftime("%Y%m%d")),
                title=os.path.splitext(os.path.basename(file_path))[0],
            ).model_dump(exclude_none=True))
        return out

    def __call__(self, file_path: str, **kwargs) -> list[dict]:
        return self.compose_vectors(self.split_documents(self.load_documents(file_path, **kwargs), **kwargs),
                                    file_path, **kwargs)


processor = DocumentProcessor()


@app.get("/health")
async def health():
    return {"status": "ok"}


@app.post("/preprocess")
async def preprocess(request: Request):
    body = await request.json()
    file_path = body.get("file_path", "")
    params = body.get("params") or {}

    if file_path == "__verify__":                               # 검증 버튼
        return {"code": 0, "errMsg": "success", "data": []}

    b64 = body.get("file_content_base64")
    if not b64 and not (file_path and os.path.exists(file_path)):
        return {"code": 1, "errMsg": "file_content_base64 도 없고 file_path 도 읽을 수 없습니다", "data": None}

    suffix = os.path.splitext(body.get("file_name") or file_path or "")[1] or ".pdf"
    tmp_path = None
    try:                                                        # 디코드 실패까지 포함해 항상 code 봉투로 응답 (500 금지)
        if b64:
            with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
                tmp.write(base64.b64decode(b64, validate=True))
                tmp_path = tmp.name
            target = tmp_path
        else:
            target = file_path                                  # base64 가 없으면 NFS 경로로 폴백
        vectors = processor(target, **params)
        return {"code": 0, "errMsg": "success", "data": vectors}
    except Exception as e:
        return {"code": 1, "errMsg": f"{type(e).__name__}: {e}", "data": None}
    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)
