"""[Flowise 워크플로우 Python Step 전용]
이 스크립트는 워크플로우 컨테이너(main_socketio.sio_server) 안에서 실행된다.
  - 화면까지 전달되는 emit 이벤트: token / sourceDocuments / agentReasoning / agentFlowExecutedData / error
  - result 는 답변 텍스트 누적용이다. token 을 이미 흘렸으면 폐기되므로 출처는 sourceDocuments 로 따로 emit 한다.
  - HITL(action)은 이 경로에서 전달되지 않는다. 필요하면 코드서빙으로 만든다 → GenOSCodeServing_main.py
  - 코드서빙(FastAPI)에서는 이 방식이 아니라 SSE `data: {"event": "token", ...}` 프레임을 쓴다.
"""
async def run(data: dict) -> dict:
    import os
    import json
    from pydantic import BaseModel, ConfigDict
    import requests
    import httpx
    from util.genos_utils import genos_import
    redis = genos_import('redis')

    r = redis.Redis(host='llmops-redis-service', port=6379, db=0)
    session_id = data.get("chatId", "")
    question = data.get("question", "")

    history = []

    def save_history(hist_list):
        if session_id:
            r.set(session_id, json.dumps(hist_list))

    # 1. 기존 히스토리 로드
    if session_id:
        raw_history = r.get(session_id)
        if raw_history:
            history = json.loads(raw_history)
            print('session_id가 존재하여 히스토리를 불러왔습니다.')
            print(f'불러온 히스토리 개수: {len(history)}')

    # 2. 현재 사용자 질문을 history에 추가
    if question:
        history.append({"role": "user", "content": question})
        save_history(history)
        print('사용자 질문을 history에 추가하였습니다.')

    class GenOSLLMServing:
        def __init__(self, serving_id: int, bearer_token: str, genos_url: str):
            self.serving_id = serving_id
            self.url = f"{genos_url}/api/gateway/rep/serving/{serving_id}"
            self.headers = dict(Authorization=f"Bearer {bearer_token}")
            self.endpoint = f"{self.url}/v1/models"
            if serving_id and bearer_token:
                print(f'model: {serving_id}번과 토큰이 입력되었습니다.')
            else:
                print('serving id 혹은 인증키가 입력되지 않았습니다.')

        def make_openai_json_schema(self, model: type[BaseModel]) -> dict:
            if not model.model_config:
                model.model_config = ConfigDict(extra = 'forbid')
            return {
                "type": "json_schema",
                "json_schema": {
                    "name": model.__name__,       # 클래스 이름 자동 반영
                    "strict": True,
                    "schema": model.model_json_schema()
                }
            }

        def call(self, system_prompt :str = '당신은 유용한 어시스턴트입니다.', question :str = '안녕?', output_format: BaseModel = None):
            """
            LLM output의 text만 내보냅니다.
            """
            body = {
                'messages' : [
                    {'role' : 'system', 'content' : system_prompt},
                    {'role' : 'user', 'content' : question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            try:
                response = requests.post(endpoint, headers=self.headers, json=body, stream=True)
                result = response.json()['choices'][0]['message']['content']
            except KeyError as e:
                print(response.json())
                print(f'llm 서빙 호출 중 keyerror 발생: {e}')
                return None
            except requests.exceptions.RequestException as e:
                print(f'llm 서빙 호출 중 오류 발생 : {e}')
                return None

            if output_format:
                return json.loads(result)
            else:
                return result

        async def async_call(self, system_prompt: str = '당신은 유용한 어시스턴트입니다.', question: str = '안녕?', output_format: BaseModel = None):
            body = {
                'messages': [
                    {'role': 'system', 'content': system_prompt},
                    {'role': 'user', 'content': question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"

            try:
                async with httpx.AsyncClient(timeout=httpx.Timeout(120.0)) as client:
                    response = await client.post(endpoint, headers=self.headers, json=body)
                result = response.json()['choices'][0]['message']['content']
            except KeyError as e:
                print(response.json())
                print(f'llm 서빙 호출 중 keyerror 발생: {e}')
                return None
            except httpx.RequestError as e:
                print(f'llm 서빙 호출 중 오류 발생 : {e}')
                return None

            if output_format:
                return json.loads(result)
            else:
                return result

        def call_all(self, system_prompt :str = '당신은 유용한 어시스턴트입니다.', question :str = '안녕?', output_format :BaseModel = None):
            """
            LLM output의 모든 데이터를 내보냅니다.
            """
            body = {
                'messages' : [
                    {'role' : 'system', 'content' : system_prompt},
                    {'role' : 'user', 'content' : question}
                ]
            }

            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            return result

        def call_with_body(self,
                           body = {
                               'messages' : [
                                   {'role' : 'system', 'content' : '당신은 유용한 어시스턴트입니다.'},
                                   {'role' : 'user', 'content' : '안녕?'}
                               ]
                           },
                           output_format :BaseModel = None):
            """
            LLM output의 모든 데이터를 내보냅니다.
            """
            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"
            response = requests.post(endpoint, headers=self.headers, json=body)
            result = response.json()
            return result

        async def async_call_with_body(self,
                                       body: dict = {
                                           'messages': [
                                               {'role': 'system', 'content': '당신은 유용한 어시스턴트입니다.'},
                                               {'role': 'user', 'content': '안녕?'}
                                           ]
                                       },
                                       output_format: BaseModel = None):
            """
            LLM output의 모든 데이터를 비동기로 요청합니다.
            """
            if output_format:
                body['response_format'] = self.make_openai_json_schema(output_format)

            endpoint = f"{self.url}/v1/chat/completions"

            async with httpx.AsyncClient() as client:
                response = await client.post(endpoint, headers=self.headers, json=body)
                response.raise_for_status()  # 오류 발생 시 예외 발생
                return response.json()

    # 환경 변수 로드
    SERVING_ID = os.getenv("LLM_SERVING_ID", "")
    BEARER_TOKEN = os.getenv("LLM_BEARER_TOKEN", "")
    GENOS_URL = os.getenv("GENOS_URL", "")

    llm = GenOSLLMServing(serving_id=SERVING_ID, bearer_token=BEARER_TOKEN, genos_url=GENOS_URL)

    # 3. System Prompt 설정
    system_prompt = "사용자의 질문에 대해 친절히 답변하세요."

    # 4. 메시지 배열 구성 (System + History + UserInput)
    # history에는 이미 과거 대화 내용과 방금 입력한 사용자 질문이 순서대로 들어있습니다.
    messages = [{"role": "system", "content": system_prompt}]
    messages.extend(history)

    body = {
        "messages": messages
    }

    # 5. call_with_body를 사용하여 LLM 호출
    response_data = llm.call_with_body(body=body)

    # 6. 응답 파싱 및 Assistant 메시지 저장
    try:
        # call_with_body는 전체 json을 반환하므로 텍스트만 추출합니다.
        answer = response_data['choices'][0]['message']['content']

        # 다음 대화를 위해 어시스턴트의 답변도 히스토리에 추가하여 Redis에 저장
        history.append({"role": "assistant", "content": answer})
        save_history(history)
        print('어시스턴트 응답을 history에 추가하였습니다.')

    except (KeyError, TypeError) as e:
        print(f"응답 파싱 오류: {e}, 원본 응답: {response_data}")
        answer = "죄송합니다. 답변을 생성하는 중 오류가 발생했습니다."

    data['text'] = answer

    return data