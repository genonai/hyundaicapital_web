"""GenOS 코드서빙 호출 클라이언트.

  POST {genos_url}/api/gateway/code_serving/{code_serving_id}[/{revision_id}]/{path}
  Authorization: Bearer {인증키}   (코드서빙 상세 > 인증 키)

응답은 코드서빙이 정하지만, 「워크플로우로 사용」 으로 등록한 앱은 아래 규약을 따른다.
  비스트리밍  {"code": 0, "errMsg": "success", "data": {"text", "sourceDocuments"}}
  스트리밍    data: {"event": "token"|"sourceDocuments"|"action"|"error"|"end", "data": ...}

멀티턴·HITL 주의. 앱 채팅에서 호출하면 genportal 이 x-genos-session-id 를 붙여 주지만,
아래처럼 외부 인증키로 직접 부르면 게이트웨이가 그 헤더를 지운다(신원 위조 방지).
그래서 세션 ID 로 상태를 찾는 앱은 매 요청을 새 대화로 본다.
직접 호출에서 대화를 이으려면 body 에 값을 넣고 앱도 그 값을 읽도록 만들어야 한다.
"""
import json
import uuid

import httpx
import requests


class GenOSCodeServing:
    def __init__(self, code_serving_id: str, bearer_token: str, genos_url: str, timeout: float = 120.0,
                 session_id: str | None = None, user_id: str = "edu-user"):
        self.code_serving_id = code_serving_id
        self.url = f"{genos_url.rstrip('/')}/api/gateway/code_serving/{code_serving_id}"
        self.session_id = session_id or str(uuid.uuid4())
        # 앱 채팅과 같은 이름으로 보내 두지만, 외부 인증키 호출에서는 게이트웨이가 제거한다(위 docstring).
        self.headers = {"Authorization": f"Bearer {bearer_token}",
                        "x-genos-session-id": self.session_id,
                        "x-genos-user-id": user_id}
        self.timeout = timeout
        print(f"code_serving_id {code_serving_id}이(가) 입력되었습니다. (session {self.session_id[:8]}…)")

    def new_session(self) -> str:
        """세션 ID 교체. 앱 채팅 경유 호출에서만 새 대화로 이어진다."""
        self.session_id = str(uuid.uuid4())
        self.headers["x-genos-session-id"] = self.session_id
        return self.session_id

    def _endpoint_url(self, endpoint: str) -> str:
        return f"{self.url}/{endpoint.lstrip('/')}"

    @staticmethod
    def _parse_sse_line(line: str):
        """'data: {...}' 한 줄 → (종료여부, payload). 빈 줄·주석은 (False, None)."""
        if not line or line.startswith(":"):
            return False, None
        if not line.startswith("data:"):
            return False, None
        data = line[len("data:"):].strip()
        if data == "[DONE]":
            return True, None
        try:
            return False, json.loads(data)
        except json.JSONDecodeError:
            return False, data  # JSON 이 아닌 평문 청크

    # ------------------------------------------------------------ 단발 호출

    def call(self, endpoint: str, body: dict = None, method: str = "POST"):
        try:
            res = requests.request(
                method, self._endpoint_url(endpoint),
                json=body, headers=self.headers, timeout=self.timeout,
            )
            return res.json()
        except Exception as e:
            print(f"코드서빙 요청 중 오류 발생:{e}")
            return None

    async def async_call(self, endpoint: str, body: dict = None, method: str = "POST"):
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(self.timeout)) as client:
                response = await client.request(
                    method, self._endpoint_url(endpoint),
                    json=body, headers=self.headers,
                )
                return response.json()
        except Exception as e:
            print(f"코드서빙 비동기 요청 중 오류 발생:{e}")
            return None

    # ------------------------------------------------------------ 스트리밍 호출

    def stream_call(self, endpoint: str, body: dict = None, method: str = "POST"):
        """SSE 청크를 도착하는 대로 yield. 제너레이터이므로 for 문으로 소비한다."""
        try:
            with requests.request(
                method, self._endpoint_url(endpoint),
                json=body, headers=self.headers, timeout=self.timeout, stream=True,
            ) as res:
                res.raise_for_status()
                for line in res.iter_lines(decode_unicode=True):
                    done, payload = self._parse_sse_line(line)
                    if done:
                        return
                    if payload is not None:
                        yield payload
        except Exception as e:
            print(f"코드서빙 스트리밍 요청 중 오류 발생:{e}")

    async def async_stream_call(self, endpoint: str, body: dict = None, method: str = "POST"):
        """SSE 청크를 도착하는 대로 yield (비동기). async for 로 소비한다."""
        try:
            async with httpx.AsyncClient(timeout=httpx.Timeout(self.timeout)) as client:
                async with client.stream(
                    method, self._endpoint_url(endpoint),
                    json=body, headers=self.headers,
                ) as response:
                    response.raise_for_status()
                    async for line in response.aiter_lines():
                        done, payload = self._parse_sse_line(line)
                        if done:
                            return
                        if payload is not None:
                            yield payload
        except Exception as e:
            print(f"코드서빙 비동기 스트리밍 요청 중 오류 발생:{e}")

    # ------------------------------------------------------------ 편의

    def stream_text(self, endpoint: str, body: dict = None) -> str:
        """스트리밍 결과를 모아 최종 텍스트 한 덩어리로 반환."""
        parts = []
        for payload in self.stream_call(endpoint, body):
            if isinstance(payload, dict):
                if payload.get("code") not in (0, None):
                    print(f"[스트리밍 오류] {payload.get('errMsg')}")
                    continue
                parts.append(((payload.get("data") or {}).get("text")) or "")
            else:
                parts.append(str(payload))
        return "".join(parts)

    # ------------------------------------------------------------ 워크플로우형(/chat) 전용

    def chat_stream(self, question: str, human_input: dict = None, path: str = "chat"):
        """/chat 을 stream=True 로 호출해 (event, data) 를 yield.

        코드서빙 채팅 규약은 `data: {"event": ..., "data": ...}` 프레임이다.
        event: token(답변 조각) / sourceDocuments(출처) / action(HITL UI) / error / end
        HITL 2턴째는 question 을 비우고 human_input 만 실어 보낸다 (GenOS 채팅앱과 동일).
        """
        body = {"question": question, "stream": True}
        if human_input:
            body["humanInput"] = human_input
        for payload in self.stream_call(path, body):
            if isinstance(payload, dict) and "event" in payload:
                yield payload["event"], payload.get("data")
                if payload["event"] == "end":
                    return

    def chat(self, question: str, path: str = "chat") -> dict:
        """/chat 비스트리밍 호출 → {"code": 0, "data": {"text": ..., "sourceDocuments": [...]}}"""
        return self.call(path, {"question": question})

